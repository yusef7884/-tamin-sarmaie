// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  //apiBaseUrl: "http://194.5.192.49:9700/api/",
  //apiBaseUrl: "http://api.karatrader.ir/api/",
  //apiBaseUrl: "http://46.102.130.70:9700/api/",
  //apiBaseUrl: "http://api.karamozd.ir:9700/api/",
  //apiBaseUrl: "http://46.102.130.70:6300/",
  apiBaseUrl: "http://46.102.130.70:6300/api/",
  
  
  
  //apiBaseUrl: "http://185.239.106.104:9700/api/",
  //apiBaseUrl: "http://94.184.176.135:9701/api/",
  signalRApiBaseUrl: "http://185.239.106.104:9701/signalHub"
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
