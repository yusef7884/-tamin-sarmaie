export const environment = {
  production: true,
  apiBaseUrl: "http://api.karatrader.ir/api/",
  signalRApiBaseUrl: "http://94.184.176.135:9000/signalHub"
};
