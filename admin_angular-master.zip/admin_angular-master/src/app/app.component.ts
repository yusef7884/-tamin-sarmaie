import { Component } from '@angular/core';
import { HttpRestService } from './core/httpRestService';
import { environment } from '../environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private restService: HttpRestService) {
    this.restService.setBaseUrl(environment.apiBaseUrl);
  }

}
