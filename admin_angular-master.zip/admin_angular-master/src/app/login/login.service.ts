import { Injectable } from '@angular/core';
import { HttpRestService } from '../core/httpRestService';

@Injectable()
export class LoginService {
    constructor(private restService: HttpRestService) { }
    api = {
        loginApi: "account/Login",
        getCaptchaApi: "Captcha/GetCaptcha"
    }

    login(command: any){
        return this.restService.post(command, this.api.loginApi);
    };
    getCaptcha(command: any){
        return this.restService.post(command, this.api.getCaptchaApi);
    };

}