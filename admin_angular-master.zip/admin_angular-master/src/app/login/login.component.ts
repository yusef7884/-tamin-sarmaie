import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {

  constructor(private service: LoginService, private router: Router) { }
  username = '';
  password = '';
  captchaValue = '';
  captchaInfo = {
    salt: '',
    hashCode: '',
    image: ''
  };
  loading = false;

  ngOnInit(): void {
    this.getCaptcha();
  }

  login() {
    this.loading = true;
    localStorage.removeItem("authentication");
    let command = {
      userName: this.username,
      passWord: this.password,
      captchaClientModel: {
        salt: this.captchaInfo.salt,
        hashed: this.captchaInfo.hashCode,
        clientValue: this.captchaValue
      }
    }
    this.service.login(command).subscribe(response => {
      if (response.success) {
        let token = response.result.accessToken;
        localStorage.setItem("authentication", token);
        this.router.navigate(['/main']);
      }else{
        this.getCaptcha();
      }
      this.loading = false;
    })
  }

  getCaptcha() {
    this.service.getCaptcha(null).subscribe((response) => {
      this.captchaInfo = response;
    })
  }
}
