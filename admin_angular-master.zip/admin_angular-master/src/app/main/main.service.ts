import { Injectable } from '@angular/core';
import { HttpRestService } from '@app/core/httpRestService';

@Injectable({
    providedIn :'root'
})
export class MainService {
    constructor(private restService: HttpRestService) { }

    api = {
        getUserInformationApi: "usermanagement/getuserinformation"
    }

    getUserInformation() {
        return this.restService.get(null, this.api.getUserInformationApi);
    }
}