import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class CustomersService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetCustomersByFilter: "party/GetCustomersByFilter",
        GetAllRoles:"usermanagement/GetAllRoles",
        Getpartybyid:"party/getpartybyid",
        ChangeRole:"usermanagement/ChangeRole",
        Assignpartytocategory:"party/assignpartytocategory",
        DeleteCategoryFromParty:"Party/DeleteCategoryFromParty",
        Saveparty:"Party/saveparty"

    }

    GetCustomersByFilter(model:any) {
        return this.restService.post(model, this.api.GetCustomersByFilter);
    }  
    GetAllRoles() {
        return this.restService.get(null, this.api.GetAllRoles);
    }  
    GetPartyById(model:any) {
        return this.restService.post(model, this.api.Getpartybyid);
    }   
    ChangeRole(model:any) {
        return this.restService.post(model, this.api.ChangeRole);
    }   
    Assignpartytocategory(model:any) {
        return this.restService.post(model, this.api.Assignpartytocategory);
    }
    DeleteCategoryFromParty(model:any) {
        return this.restService.post(model, this.api.DeleteCategoryFromParty);
    }  
    Saveparty(model:any) {
        return this.restService.post(model, this.api.Saveparty);
    }    
      
    
}