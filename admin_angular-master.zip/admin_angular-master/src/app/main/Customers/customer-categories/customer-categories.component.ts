import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CategoriesService } from '@app/main/Categories/CategoriesService';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomersService } from '../CustomersService';

@Component({
  selector: 'app-customer-categories',
  templateUrl: './customer-categories.component.html',
  styleUrls: ['./customer-categories.component.css'],
  providers: [CategoriesService, CustomersService]
})
export class CustomerCategoriesComponent implements OnInit {
  @Input() PartyId: any;
  @Input() Name: any;
  @Input() NationalCode: any;

  CategoryId: any;
  CurrentCategories: any[];
  AllCategories: any[];
  frm: FormGroup;
  constructor(private activeModal: NgbActiveModal,
    private categoriesService: CategoriesService,
    private customersService: CustomersService
  ) { }

  ngOnInit(): void {
    this.LoadData();
  }

  LoadData() {
    if (this.PartyId) {

      this.categoriesService.GetCategoriesByPartyId({ entity: this.PartyId }).subscribe(response => {
        if (response.success) {
          this.CurrentCategories = response.result;
        }
      });
      this.categoriesService.GetCategories().subscribe(response => {
        if (response.success) {
          this.AllCategories = response.result;
        }
      });

    }


  }


  Delete(id: any) {
    if (id) {
      this.customersService.DeleteCategoryFromParty({entity: {partyId: this.PartyId, categoryId: id}}).subscribe(response => {
        if (response.success) {
          this.LoadData();
        }
      });
    }
  }
  cancel() {
    this.activeModal.close();
  }

  Add() {
    if (this.CategoryId) {
      this.customersService.Assignpartytocategory({entity:{partyId:this.PartyId,categoryId:this.CategoryId}}).subscribe(response => {
        if (response.success) {
          this.LoadData();
        }
      });
    }

  }

}
