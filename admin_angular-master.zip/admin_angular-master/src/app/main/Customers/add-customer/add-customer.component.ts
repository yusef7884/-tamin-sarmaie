import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CustomersService } from '../CustomersService';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css'],
  providers: [CustomersService]
})
export class AddCustomerComponent implements OnInit {


  frm: FormGroup;
  constructor(private activeModal: NgbActiveModal,
    private customersService: CustomersService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {

    this.initialForm();
  }


  initialForm() {
    this.frm = this.formBuilder.group({

      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      nationalCode: [''],
      phoneNumber: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    });
  }
  Save() {
    if (this.frm.valid) {
      var param = {
        entity:
        {
          firstName: this.frm.controls.firstName,
          lastName: this.frm.controls.lastName,
          nationalCode: this.frm.controls.nationalCode,
          phoneNumber: this.frm.controls.phoneNumber,
          email: this.frm.controls.email,
          password: this.frm.controls.password,
          confirmPassword: this.frm.controls.confirmPassword
        }
      }
      this.customersService.Saveparty(param).subscribe(response => {
        if (response.success) {
          this.activeModal.close();
        }
      });

    }
  }
  cancel() {
    this.activeModal.close();
  }


}