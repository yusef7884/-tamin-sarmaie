export class CustomersModel {
    birthDate?: any;
    created?: any;
    createdBy?: string;
    email?: string;
    fatherName?: string;
    firstName?: string;
    fullName?: string;
    gender?: any;
    id?: number;
    identityCard?: any
    lastName?: string;
    mobile?: string;
    modified?: any;
    modifiedBy?: string;
    nationalCode?: string;
    partyStatus?: number;
    password?: any;
    roleName?: string;
    userId?: string;
    userName?: string;
}


