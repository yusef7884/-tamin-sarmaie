import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeRuleComponent } from './change-rule.component';

describe('ChangeRuleComponent', () => {
  let component: ChangeRuleComponent;
  let fixture: ComponentFixture<ChangeRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
