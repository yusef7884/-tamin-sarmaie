import { Component, OnInit } from '@angular/core';
import { ButtonRendererComponent } from '@app/shared/ButtonRenderer/ButtonRendererComponent';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddCustomerComponent } from '../add-customer/add-customer.component';
import { ChangeRuleComponent } from '../change-rule/change-rule.component';
import { CustomerCategoriesComponent } from '../customer-categories/customer-categories.component';
import { CustomersModel } from '../Customers.Model';
import { CustomersService } from '../CustomersService';

@Component({
  selector: 'app-customers-index',
  templateUrl: './customers-index.component.html',
  styleUrls: ['./customers-index.component.css'],
  providers: [CustomersService],
})
export class CustomersIndexComponent implements OnInit {
  rowData: CustomersModel[] = [];
  frameworkComponents: any;
  public localeText = {
    page: "صفحه",
    More: "بیشتر",
    to: "تا",
    of: "از",
    next: "صفحه بعد",
    last: "صفحه قبل",
    first: "ابتدا",
    previous: "صفحه قبل",
    loadingOoo: "درحال فراخوانی...",
    selectAll: "Query all",
    searchOoo: "query...",
    blanks: "blank",
    filterOoo: "فیلتر...",
    applyFilter: "daApplyFilter...",
    equals: "مساوی",
    notEqual: "نا مساوی",
    lessThan: "کمتر از",
    greaterThan: "بیشتر از",
    lessThanOrEqual: "کمتر یا مساوی با",
    greaterThanOrEqual: "بیشتر یا مساوی با",
    inRange: "در بازه",
    contains: "شامل",
    notContains: "شامل نباشد",
    startsWith: "شروع شود با",
    endsWith: "پایان یابد با",
    Group: "گروه",
    columns: "ستونها",
    filters: "فیلتر",
    rowGroupColumns: "ستونهای گروهی",
    rowGroupColumnsEmptyMessage: "ستونهای گروهی خالی هستند",
    valueColumns: "مقادیر ستونها",
    pivotMode: "حالت پیوت",
    groups: "گروهها",
    values: "مقدار",
    pivots: "پیوت",
    valueColumnsEmptyMessage: "خالی",
    pivotColumnsEmptyMessage: "خالی",
    toolPanelButton: "کلید پنل ابزار",
    noRowsToShow: "هیج دیتای برای نمایش وجود ندارد",
    pinColumn: "ستون پین شده",
    valueAggregation: "مجموع",
    autosizeThiscolumn: "ستون تغییر اندازه پذیر",
    autosizeAllColumns: "ستونهای قابل تغییر اندازه",
    groupBy: "مرتب سازی",
    ungroupBy: "نامرتب سازی",
    resetColumns: "ریست کردن ستون",
    expandAll: "گسترش دادن همه",
    collapseAll: "جمع کردن",
    toolPanel: "ابزار ",
    export: "خروجی گرفتن",
    csvExport: "خروجی گرفتن با فرمت csv",
    excelExport: "ارسال به اکسل",
    pinLeft: "پین &lt;&lt;",
    pinRight: "پین &gt;&gt;",
    noPin: "بدون پین &lt;&gt;",
    sum: "جمع",
    min: "کمترین",
    max: "بیشترین",
    none: "هیچکدام",
    count: "تعداد",
    average: "میانگین",
    copy: "کپی",
    copyWithHeaders: "کپی همراه با هدر",
    ctrlC: "ctrl + C",
    paste: "چسپاندن",
    ctrlV: "ctrl + V",
  };
  numberComparator = function (number1, number2) {
    if (number1 === null && number2 === null) {
      return 0;
    }
    if (number1 === null) {
      return -1;
    }
    if (number2 === null) {
      return 1;
    }
    return number1 - number2;
  };
  columnDefs = [
    {
      headerName: 'دسته بندی',
      minWidth: 100,
      header: "Action",
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.ChangeCategory.bind(this),
        iconClass: 'fa fa-edit user-icon'
      }
    },
    {
      headerName: 'نقش',
      minWidth: 100,
      header: "Action",
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.ChangeRule.bind(this),
        iconClass: 'green-page fa fa-user-tag user-icon'
      }
    },
    {
      headerName: "تایید شده",
      flex: 1,
      minWidth: 100,
      field: "partyStatus",
      headerTooltip: "تایید شده",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
      cellRenderer: (params) => {
        if (params.data.partyStatus === 1)
          return '<span class="green-page fa fa-check user-icon"></span>';
        else if (params.data.partyStatus === 2)
          return '<span style="color:red" class="fa fa-exclamation user-icon"></span>';
        else
          return ''


      },

    },
    {
      headerName: "آخرین ورود",
      flex: 1,
      minWidth: 100,
      field: "birthDate",
      headerTooltip:"آخرین ورود",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نقش مشتری",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "roleName",
      headerTooltip: "نقش مشتری",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نام پدر",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "fatherName",
      headerTooltip: "نام پدر",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "کد ملی",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "nationalCode",
      headerTooltip:"کد ملی",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نام خانوادگی",
      flex: 1,
      minWidth: 300,
      width: 350,
      field: "lastName",
      headerTooltip: "نام خانوادگی",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نام",
      flex: 1,
      minWidth: 100,
      field: "firstName",
      headerTooltip: "نام",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },

  ];
  public noRowsTemplate: string;
  public loadingTemplate: string;
  private gridApi;



  constructor(private modalService: NgbModal, private customersService: CustomersService
  ) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.loadingTemplate = `<span class="ag-overlay-loading-center">لطفا صبر کنید...</span>`;
    this.noRowsTemplate = `<span>هیج دیتای برای نمایش وجود ندارد</span>`;

    this.LoadData();
  }
  LoadData() {
    var param = {
      reportFilter:{name:"",lastName:"",rolId:"",activity:{}},
      OptionalFilter:{take:50,page:0,sort:[{field:"Created",dir:"desc"}]}
    }
    this.customersService.GetCustomersByFilter(param).subscribe(response => {
      if (response.success) {
        this.rowData = response.result;
        this.gridApi.setRowData(this.rowData);
      }
    });
  }
  onGridReady(params) {
    this.gridApi = params.api; 
  }
  ChangeRule(e){
    const modalRef = this.modalService.open(ChangeRuleComponent, {
      size: "xl"
    });
    modalRef.componentInstance.roleName = e.rowData.roleName;
    modalRef.componentInstance.Name = e.rowData.fullName;
    modalRef.componentInstance.NationalCode = e.rowData.nationalCode;
    modalRef.componentInstance.userName = e.rowData.userName;
    
    modalRef.result.then((response: any) => {
      this.LoadData();
    })
  }
  AddCustomer(){
    const modalRef = this.modalService.open(AddCustomerComponent, {
      size: "xl"
    });
    modalRef.result.then((response: any) => {
      this.LoadData();
    })
  }
  ChangeCategory(e){
    const modalRef = this.modalService.open(CustomerCategoriesComponent, {
      size: "xl"
    });
    modalRef.componentInstance.PartyId = e.rowData.id;  
    modalRef.componentInstance.Name = e.rowData.fullName;  
    modalRef.componentInstance.NationalCode = e.rowData.nationalCode;
    modalRef.result.then((response: any) => {
      this.LoadData();
    })
  }
}
