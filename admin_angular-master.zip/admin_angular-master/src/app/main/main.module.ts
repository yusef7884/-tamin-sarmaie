import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { mainRoutes } from './main-routes';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { AuthGuard } from '../shared/authentication/auth-guard.service';
import { RepositoryService } from '@app/services/repository.service';
import { ErrorsModule } from '../errors/errors.module';
import { AutoFocusDirective } from '@app/shared/directives/auto-focus.directive';
import { SharedModule } from '@app/shared/shared.module';
import { AngularSvgIconModule } from 'angular-svg-icon';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ProfileComponent } from './profile/profile.component';
import { NewsIndexComponent } from './News/news-index/news-index.component';
import { CategoriesIndexComponent } from './Categories/categories-index/categories-index.component';
import { AgGridModule } from 'ag-grid-angular';
import { ButtonRendererComponent } from '@app/shared/ButtonRenderer/ButtonRendererComponent';
import { NewsEditComponent } from './News/news-edit/news-edit.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NewsAddComponent } from './News/news-add/news-add.component';
import { CustomersIndexComponent } from './Customers/customers-index/customers-index.component';
import { ChangeRuleComponent } from './Customers/change-rule/change-rule.component';
import { CustomerCategoriesComponent } from './Customers/customer-categories/customer-categories.component';
import { AddCustomerComponent } from './Customers/add-customer/add-customer.component';
import { UsersIndexComponent } from './Users/users-index/users-index.component';
import { UsersChangeRuleComponent } from './Users/users-change-rule/users-change-rule.component';
import { UsersResetPasswordComponent } from './Users/users-reset-password/users-reset-password.component';
import { PaymentsIndexComponent } from './Accounting/payments-index/payments-index.component';
import { NewsUsersComponent } from './Performance/news-users/news-users.component';


@NgModule({
  declarations: [
    MainComponent,
    NavbarComponent,
    SidebarComponent,
    AutoFocusDirective,
    ChangePasswordComponent,
    ProfileComponent,
    NewsIndexComponent,
    CategoriesIndexComponent,
    ButtonRendererComponent,
    NewsEditComponent,
    NewsAddComponent,
    CustomersIndexComponent,
    ChangeRuleComponent,
    CustomerCategoriesComponent,
    AddCustomerComponent,
    UsersIndexComponent,
    UsersChangeRuleComponent,
    UsersResetPasswordComponent,
    PaymentsIndexComponent,
    NewsUsersComponent
  ],
  imports: [
    CommonModule,
    ErrorsModule,
    SharedModule,
    RouterModule.forChild(mainRoutes),
    AngularSvgIconModule.forRoot(),
    AgGridModule.withComponents([ButtonRendererComponent]),   
    MatAutocompleteModule 
    
  ],
  providers: [RepositoryService, AuthGuard, DecimalPipe]
})
export class MainModule {

}
