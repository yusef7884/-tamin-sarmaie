import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class NavbarService {
    constructor(private restService: HttpRestService) { }

    api = {
        marketIndicesApi: "marketindice/getmarketindices"
    }

    marketIndices(){
        return this.restService.get(null, this.api.marketIndicesApi)
    }
}