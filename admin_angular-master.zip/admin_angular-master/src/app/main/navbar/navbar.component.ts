import { Component, OnInit } from '@angular/core';
import { NavbarService } from './navbar.service';
import { RepositoryService } from '@app/services/repository.service';
import { Router } from '@angular/router';
import { ChangePasswordComponent } from '../change-password/change-password.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  providers: [NavbarService]
})
export class NavbarComponent implements OnInit {

  constructor(
    private service: NavbarService,
    private repositoryService: RepositoryService,
    private modalService: NgbModal,
    private router: Router) { }
  currentTime: any;
  custometInfo: any;
  marketIndicesInfo = {
    id: 0,
    index: 0,
    indexChange: 0,
    indexChangePercent: 0,
    marketValue: 0,
    bourseVolume: 0,
    bourseValue: 0,
    bourseQuantity: 0,
    faraBourseVolume: 0,
    faraBourseValue: 0,
    faraBourseQuantity: 0,
    drriveVolume: 0,
    drriveValue: 0,
    drriveQuantity: 0,
    recivedTime: Date.now,
  };
  ngOnInit(): void {
    this.currentDateAndTime();
    this.getCustomerInfo();
    this.marketIndices();
  }

  currentDateAndTime() {
    setInterval(() => {
      this.currentTime = new Date()
    }, 1000)
  }

  getCustomerInfo() {
    this.repositoryService.user.getUserInfo().subscribe(response => {
      this.custometInfo = response;
    });
  };

  signOut() {
    this.router.navigate(['login']);
    localStorage.removeItem("authentication");
    this.repositoryService.user.removeUser();
  }
  marketIndices() {
    this.service.marketIndices().subscribe((response) => {
      if (response.success) {
        this.marketIndicesInfo = response.result;
        this.marketIndicesInfo.marketValue = parseFloat((this.marketIndicesInfo.marketValue / 1000000000).toFixed(2));
        this.marketIndicesInfo.bourseVolume = parseFloat((this.marketIndicesInfo.bourseVolume / 1000000000).toFixed(2));
        this.marketIndicesInfo.bourseValue = parseFloat((this.marketIndicesInfo.bourseValue / 1000000000).toFixed(2));
        this.marketIndicesInfo.faraBourseVolume = parseFloat((this.marketIndicesInfo.faraBourseVolume / 1000000000).toFixed(2));
        this.marketIndicesInfo.faraBourseValue = parseFloat((this.marketIndicesInfo.faraBourseValue / 1000000000).toFixed(2));
      }
    })
  }
  changePassWord() {
    const modalRef = this.modalService.open(ChangePasswordComponent);
  }
}
