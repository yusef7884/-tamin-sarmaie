import { Component, OnInit } from '@angular/core';
import { HttpRestService } from '../core/httpRestService';
import { RepositoryService } from '@app/services/repository.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})

export class MainComponent implements OnInit {
  constructor(private restService: HttpRestService,
    private repositoryService: RepositoryService, private router: Router) { }

  ngOnInit() {
    let token = localStorage.getItem("authentication");
    this.restService.addHeader('Authorization', 'Bearer ' + token);
    
  }
}
