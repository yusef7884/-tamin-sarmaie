import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-index',
  templateUrl: './categories-index.component.html',
  styleUrls: ['./categories-index.component.css']
})
export class CategoriesIndexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
