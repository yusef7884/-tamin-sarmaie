import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class CategoriesService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetCategories: "Category/GetCategories",
        GetCategoriesByPartyId:"Category/GetCategoriesByPartyId"
    }

    GetCategories() {
        return this.restService.post({}, this.api.GetCategories);
    }    
    GetCategoriesByPartyId(model) {
        return this.restService.post(model, this.api.GetCategoriesByPartyId);
    }    
}