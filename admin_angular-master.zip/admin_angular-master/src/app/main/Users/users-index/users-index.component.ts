import { Component, OnInit } from '@angular/core';
import { ButtonRendererComponent } from '@app/shared/ButtonRenderer/ButtonRendererComponent';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UsersChangeRuleComponent } from '../users-change-rule/users-change-rule.component';
import { UsersResetPasswordComponent } from '../users-reset-password/users-reset-password.component';
import { UserModel } from '../UsersModel';
import { UsersService } from '../UsersService';

@Component({
  selector: 'app-users-index',
  templateUrl: './users-index.component.html',
  styleUrls: ['./users-index.component.css'],
  providers: [UsersService],
})
export class UsersIndexComponent implements OnInit {
  rowData: UserModel[] = [];
  frameworkComponents: any;
  public localeText = {
    page: "صفحه",
    More: "بیشتر",
    to: "تا",
    of: "از",
    next: "صفحه بعد",
    last: "صفحه قبل",
    first: "ابتدا",
    previous: "صفحه قبل",
    loadingOoo: "درحال فراخوانی...",
    selectAll: "Query all",
    searchOoo: "query...",
    blanks: "blank",
    filterOoo: "فیلتر...",
    applyFilter: "daApplyFilter...",
    equals: "مساوی",
    notEqual: "نا مساوی",
    lessThan: "کمتر از",
    greaterThan: "بیشتر از",
    lessThanOrEqual: "کمتر یا مساوی با",
    greaterThanOrEqual: "بیشتر یا مساوی با",
    inRange: "در بازه",
    contains: "شامل",
    notContains: "شامل نباشد",
    startsWith: "شروع شود با",
    endsWith: "پایان یابد با",
    Group: "گروه",
    columns: "ستونها",
    filters: "فیلتر",
    rowGroupColumns: "ستونهای گروهی",
    rowGroupColumnsEmptyMessage: "ستونهای گروهی خالی هستند",
    valueColumns: "مقادیر ستونها",
    pivotMode: "حالت پیوت",
    groups: "گروهها",
    values: "مقدار",
    pivots: "پیوت",
    valueColumnsEmptyMessage: "خالی",
    pivotColumnsEmptyMessage: "خالی",
    toolPanelButton: "کلید پنل ابزار",
    noRowsToShow: "هیج دیتای برای نمایش وجود ندارد",
    pinColumn: "ستون پین شده",
    valueAggregation: "مجموع",
    autosizeThiscolumn: "ستون تغییر اندازه پذیر",
    autosizeAllColumns: "ستونهای قابل تغییر اندازه",
    groupBy: "مرتب سازی",
    ungroupBy: "نامرتب سازی",
    resetColumns: "ریست کردن ستون",
    expandAll: "گسترش دادن همه",
    collapseAll: "جمع کردن",
    toolPanel: "ابزار ",
    export: "خروجی گرفتن",
    csvExport: "خروجی گرفتن با فرمت csv",
    excelExport: "ارسال به اکسل",
    pinLeft: "پین &lt;&lt;",
    pinRight: "پین &gt;&gt;",
    noPin: "بدون پین &lt;&gt;",
    sum: "جمع",
    min: "کمترین",
    max: "بیشترین",
    none: "هیچکدام",
    count: "تعداد",
    average: "میانگین",
    copy: "کپی",
    copyWithHeaders: "کپی همراه با هدر",
    ctrlC: "ctrl + C",
    paste: "چسپاندن",
    ctrlV: "ctrl + V",
  };
  numberComparator = function (number1, number2) {
    if (number1 === null && number2 === null) {
      return 0;
    }
    if (number1 === null) {
      return -1;
    }
    if (number2 === null) {
      return 1;
    }
    return number1 - number2;
  };
  columnDefs = [
    {
      headerName: 'تغییر رمز عبور',
      minWidth: 100,
      header: "Action",
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.ResetPassword.bind(this),
        iconClass: 'fa fa-lock user-icon ActionBtns'
      }
    },
    {
      headerName: 'تغییر نقش',
      minWidth: 100,
      header: "Action",
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.ChangeRule.bind(this),
        iconClass: 'fa fa-bullseye user-icon ActionBtns'
      }
    },
    {
      headerName: "نقش",
      flex: 1,
      minWidth: 100,
      field: "roleName",
      headerTooltip: "نقش",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "تاریخ ثبت",
      flex: 1,
      minWidth: 100,
      field: "createdJalaliDate",
      headerTooltip: "تاریخ ثبت",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "ایمیل",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "email",
      headerTooltip: "ایمیل",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نام و نام خانوادگی",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "displayName",
      headerTooltip: "نام پدر",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نام کاربری",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "userName",
      headerTooltip: "کد ملی",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    }

  ];
  public noRowsTemplate: string;
  public loadingTemplate: string;
  private gridApi;



  constructor(private modalService: NgbModal,
    private usersService: UsersService
  ) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.loadingTemplate = `<span class="ag-overlay-loading-center">لطفا صبر کنید...</span>`;
    this.noRowsTemplate = `<span>هیج دیتای برای نمایش وجود ندارد</span>`;

    this.LoadData();
  }
  LoadData() {
    var param = {
      reportFilter: { name: "", lastName: "", rolId: "" },
      OptionalFilter: { take: 50, page: 0, sort: [{ field: "CreatedJalaliDate", dir: "desc" }] }
    }
    this.usersService.GetAllUsers(param).subscribe(response => {
      if (response.success) {
        this.rowData = response.result;
        this.gridApi.setRowData(this.rowData);
      }
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
  }
  ChangeRule(e) {
    const modalRef = this.modalService.open(UsersChangeRuleComponent, {
      size: "xl"
    });
    modalRef.componentInstance.roleName = e.rowData.roleName;
    modalRef.componentInstance.Name = e.rowData.displayName;
    modalRef.componentInstance.NationalCode = e.rowData.nationalId;
    modalRef.componentInstance.userName = e.rowData.userName;

    modalRef.result.then((response: any) => {
      this.LoadData();
    })
  }

  ResetPassword(e) {
    const modalRef = this.modalService.open(UsersResetPasswordComponent, {
      size: "xl"
    });
    modalRef.componentInstance.PartyId = e.rowData.id;
    modalRef.componentInstance.Name = e.rowData.fullName;
    modalRef.componentInstance.NationalCode = e.rowData.nationalCode;
    modalRef.componentInstance.userName = e.rowData.userName;
    
    modalRef.result.then((response: any) => {
      this.LoadData();
    })
  }
  AddUser(){

  }
}
