import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class UsersService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetAllUsers: "usermanagement/GetAllUsers",
        Changepassworduser:"account/ChangePassword"
     
    }

    GetAllUsers(model:any) {
        return this.restService.post(model, this.api.GetAllUsers);
    }  
    Changepassworduser(model:any) {
        return this.restService.post(model, this.api.Changepassworduser);
    }  
    
      
    
}