export class UserModel{
    confirmPassword?: string;
    createDate?: any;
    createdJalaliDate?: string;
    displayName?:  string;
    email?:  string;
    fullName?:  string;
    id?:  string;
    nationalId?:  string;
    partyId?: number;
    partyStatus?: number;
    partyStatusDescription?:  string;
    password?:  string;
    phoneNumber?:  string;
    roleId?:  string;
    roleName?:  string;
    status?: number;
    statusDescription?:  string;
    userName?:  string;
}
