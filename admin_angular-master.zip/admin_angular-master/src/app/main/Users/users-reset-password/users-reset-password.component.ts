import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomersService } from '@app/main/Customers/CustomersService';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UsersService } from '../UsersService';

@Component({
  selector: 'app-users-reset-password',
  templateUrl: './users-reset-password.component.html',
  styleUrls: ['./users-reset-password.component.css'],
  providers: [UsersService]

})
export class UsersResetPasswordComponent implements OnInit {
  @Input() Name: any;
  @Input() NationalCode: any;
  @Input() userName: string;

  
  frm: FormGroup;
  constructor(private activeModal: NgbActiveModal,
    private usersService: UsersService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.frm = this.formBuilder.group({
      password: ['', Validators.required]
    });
  }

  Save() {
    debugger;
    var param={
      entity:{
        password:this.frm.controls.password.value,
        userName: this.userName
      }
    };
    this.usersService.Changepassworduser(param).subscribe(response => {
      if (response.success) {
        this.activeModal.close();
      }
    });
  }
  cancel() {
    this.activeModal.close();
  }
}


