import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsersChangeRuleComponent } from './users-change-rule.component';

describe('UsersChangeRuleComponent', () => {
  let component: UsersChangeRuleComponent;
  let fixture: ComponentFixture<UsersChangeRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsersChangeRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsersChangeRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
