import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CustomersService } from '@app/main/Customers/CustomersService';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-users-change-rule',
  templateUrl: './users-change-rule.component.html',
  styleUrls: ['./users-change-rule.component.css'],
  providers: [CustomersService]
})
export class UsersChangeRuleComponent implements OnInit {
  @Input() roleName: any;
  @Input() Name: any;
  @Input() NationalCode: any;
  @Input() userName: string;

  AllRoles:any[];
  frm: FormGroup;
  constructor(private activeModal: NgbActiveModal,
    private customersService: CustomersService
  ) { }

  ngOnInit(): void {
    this.LoadData();
  }

  LoadData() {

    this.customersService.GetAllRoles().subscribe(response => {
      if (response.success) {
        this.AllRoles = response.result;
      }
    });
 

  }
  
  Save() {
    this.userName
    var param={
      entity:{
        roleName:this.roleName,
        userName: this.userName
      }
    };
    this.customersService.ChangeRole(param).subscribe(response => {
      if (response.success) {
        this.activeModal.close();
      }
    });
  }
  cancel() {
    this.activeModal.close();
  }
}


