import { Injectable } from '@angular/core';
import { HttpRestService } from 'src/app/core/httpRestService';

@Injectable()
export class SideBarService {
    constructor(private restService: HttpRestService) { }

    api = {
        getAllAccessedMenuApi: "resource/getallaccessedmenu",
    };

    getAllAccessedMenu() {
        return this.restService.get(null, this.api.getAllAccessedMenuApi);
    }

}