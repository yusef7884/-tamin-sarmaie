import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SideBarService } from './sidebar.service';
import { Location } from "@angular/common";
import { Router, NavigationEnd  } from '@angular/router';
import { RepositoryService } from '@app/services/repository.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  providers: [SideBarService],
  encapsulation: ViewEncapsulation.None
})

export class SidebarComponent implements OnInit {
  // isExpandedDashboard=false;
  // isExpandedBasket=false;
  isExpanded: boolean[]=[];
  position=false;
  id:any;
  isHide=true;
  custometInfo:any;
  constructor(private service: SideBarService, private router : Router , private location :Location ,private repositoryService: RepositoryService) {
    router.events.subscribe(event => {
        if(event instanceof NavigationEnd){
        }
       
    });
  }
  menuList:any []=[];;
  currentState = null;

  ngOnInit(): void {
    this.getAllAccessedMenu();
    this.getCustomerInfo();

  var el=document.getElementsByClassName('sider');
   for (let asd = 0; asd < el.length; asd++) {
      this.isExpanded.push(false);
     
   }   
  }

  getAllAccessedMenu() {
    this.service.getAllAccessedMenu().subscribe(response => {
      if (response.success) {
        this.menuList = response.result;
      }
    });
    
   
  }

  getCustomerInfo() {
    this.repositoryService.user.getUserInfo().subscribe(response => {
      this.custometInfo = response;
    });
  }

  onChildMenuClick(menu: string) {

  }
 
  mouseleave() {
    this.isHide=!this.isHide;
    this.isExpanded[this.id]=false;
    // this.isExpandedDashboard =false;
    // this.isExpandedBasket=false;
  
  //  if(this.id)
  //  document.getElementById(this.id).style.backgroundColor = '#2d323e';

  }
  mouseenter(){
     
    this.isHide=!this.isHide;
    this.isExpanded[this.id]=false;
    if(this.position)
    {
      this.isExpanded[this.id]=true;
      document.getElementById(this.id).style.backgroundColor = '#1e2129'; 
    }
  }
  click(id){
    this.id=id;
    
    // this.isExpanded=!this.isExpanded;

    this.position=this.isExpanded[this.id];
     // this.isExpandedBasket==!this.isExpandedBasket;
    // console.log(this.isExpandedBasket);
    
    // if(this.isExpanded[id])    
    //   // document.getElementById(this.id).style.backgroundColor = 'rgba(0,0,0,.12)'; 
      
    // else
    // document.getElementById(this.id).style.backgroundColor = '#2d323e';
  }


}
