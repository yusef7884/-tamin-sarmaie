import { Routes } from '@angular/router';
import { PaymentsIndexComponent } from './Accounting/payments-index/payments-index.component';
import { CategoriesIndexComponent } from './Categories/categories-index/categories-index.component';
import { CustomersIndexComponent } from './Customers/customers-index/customers-index.component';
import { MainComponent } from './main.component';
import { NewsIndexComponent } from './News/news-index/news-index.component';
import { NewsUsersComponent } from './Performance/news-users/news-users.component';
import { UsersIndexComponent } from './Users/users-index/users-index.component';

export const mainRoutes: Routes = [

    {
        path: 'main',
        component: MainComponent,
        children: [
            {
                path: 'manager',
                children:[
                    {
                        path: 'getNews',
                        component: NewsIndexComponent,
                    },
                    {
                        path: 'getCategories',
                        component: CategoriesIndexComponent,
                    }
                ]
            },
            {
                path: 'customers',
                children:[
                    {
                        path: 'list',
                        component: CustomersIndexComponent,
                    }
                ]
            },
            {
                path: 'Performance',
                children:[
                    {
                        path: 'NewsUsers',
                        component: NewsUsersComponent,
                    }
                ]
            },
            {
                path: 'accounting',
                children:[
                    {
                        path: 'getPaymentsList',
                        component: PaymentsIndexComponent,
                    }
                ]
            },
            {
                path: 'resource',
                children:[
                    {
                        path: 'users',
                        children:[
                            {
                                path: 'getUsers',
                                component: UsersIndexComponent,
                            }
                        ]
                    }
                ]
            }


            
        ]
    }
];