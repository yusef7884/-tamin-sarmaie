export class AccountingModel {
    amount?: number;
    createDate?: string;
    createJalaliDate?: string;
    expirationDate?: any;
    expirationJalaliDate?: string;
    fullName?: string;
    id?: number;
    nationalCode?: string;
    partyId?: number;
    paymentId?: number;
    paymentRequestName?: string;
    paymentStatus?: number;
    paymentStatusTitle?: string;
    paymentTitle?: null
    referenceId?: string;
    uniqId?: number;
    userId?: string;
    userName?: string;
}
