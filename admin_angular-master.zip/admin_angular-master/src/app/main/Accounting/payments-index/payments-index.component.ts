import { Component, OnInit } from '@angular/core';
import { UsersService } from '@app/main/Users/UsersService';
import { ButtonRendererComponent } from '@app/shared/ButtonRenderer/ButtonRendererComponent';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AccountingModel } from '../AccountingModel';
import { AccountingService } from '../AccountingService';

@Component({
  selector: 'app-payments-index',
  templateUrl: './payments-index.component.html',
  styleUrls: ['./payments-index.component.css'],
  providers: [AccountingService]
})
export class PaymentsIndexComponent implements OnInit {
  rowData: AccountingModel[] = [];
  frameworkComponents: any;
  public localeText = {
    page: "صفحه",
    More: "بیشتر",
    to: "تا",
    of: "از",
    next: "صفحه بعد",
    last: "صفحه قبل",
    first: "ابتدا",
    previous: "صفحه قبل",
    loadingOoo: "درحال فراخوانی...",
    selectAll: "Query all",
    searchOoo: "query...",
    blanks: "blank",
    filterOoo: "فیلتر...",
    applyFilter: "daApplyFilter...",
    equals: "مساوی",
    notEqual: "نا مساوی",
    lessThan: "کمتر از",
    greaterThan: "بیشتر از",
    lessThanOrEqual: "کمتر یا مساوی با",
    greaterThanOrEqual: "بیشتر یا مساوی با",
    inRange: "در بازه",
    contains: "شامل",
    notContains: "شامل نباشد",
    startsWith: "شروع شود با",
    endsWith: "پایان یابد با",
    Group: "گروه",
    columns: "ستونها",
    filters: "فیلتر",
    rowGroupColumns: "ستونهای گروهی",
    rowGroupColumnsEmptyMessage: "ستونهای گروهی خالی هستند",
    valueColumns: "مقادیر ستونها",
    pivotMode: "حالت پیوت",
    groups: "گروهها",
    values: "مقدار",
    pivots: "پیوت",
    valueColumnsEmptyMessage: "خالی",
    pivotColumnsEmptyMessage: "خالی",
    toolPanelButton: "کلید پنل ابزار",
    noRowsToShow: "هیج دیتای برای نمایش وجود ندارد",
    pinColumn: "ستون پین شده",
    valueAggregation: "مجموع",
    autosizeThiscolumn: "ستون تغییر اندازه پذیر",
    autosizeAllColumns: "ستونهای قابل تغییر اندازه",
    groupBy: "مرتب سازی",
    ungroupBy: "نامرتب سازی",
    resetColumns: "ریست کردن ستون",
    expandAll: "گسترش دادن همه",
    collapseAll: "جمع کردن",
    toolPanel: "ابزار ",
    export: "خروجی گرفتن",
    csvExport: "خروجی گرفتن با فرمت csv",
    excelExport: "ارسال به اکسل",
    pinLeft: "پین &lt;&lt;",
    pinRight: "پین &gt;&gt;",
    noPin: "بدون پین &lt;&gt;",
    sum: "جمع",
    min: "کمترین",
    max: "بیشترین",
    none: "هیچکدام",
    count: "تعداد",
    average: "میانگین",
    copy: "کپی",
    copyWithHeaders: "کپی همراه با هدر",
    ctrlC: "ctrl + C",
    paste: "چسپاندن",
    ctrlV: "ctrl + V",
  };

  columnDefs = [
    {
      headerName: "اتمام اشتراک",
      flex: 1,
      minWidth: 100,
      field: "expirationJalaliDate",
      headerTooltip: "اتمام اشتراک",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "تاریخ ایجاد",
      flex: 1,
      minWidth: 100,
      field: "createJalaliDate",
      headerTooltip: "تاریخ ایجاد",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "وضعیت پرداخت",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "paymentStatusTitle",
      headerTooltip: "وضعیت پرداخت",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "شناسه مرجع",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "referenceId",
      headerTooltip: "شناسه مرجع",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "درگاه",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "paymentRequestName",
      headerTooltip: "درگاه",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "نوع اشتراک",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "paymentTitle",
      headerTooltip: "نوع اشتراک",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "شناسه اشتراک",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "paymentId",
      headerTooltip: "شناسه اشتراک",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "مبلغ",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "amount",
      headerTooltip: "مبلغ",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "شناسه",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "uniqId",
      headerTooltip: "شناسه",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "کد ملی",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "nationalCode",
      headerTooltip: "کد ملی",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },
    {
      headerName: "نام",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "userName",
      headerTooltip: "نام",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    },


  ];
  public noRowsTemplate: string;
  public loadingTemplate: string;
  private gridApi;



constructor(private modalService: NgbModal,
  private accountingService: AccountingService
) {
  this.frameworkComponents = {
    buttonRenderer: ButtonRendererComponent,
  }
}

ngOnInit(): void {
  this.loadingTemplate = `<span class="ag-overlay-loading-center">لطفا صبر کنید...</span>`;
  this.noRowsTemplate = `<span>هیج دیتای برای نمایش وجود ندارد</span>`;

  this.LoadData();
}
LoadData() {
  var param = {
    reportFilter: { partyId:10016,FromDate:"2020-12-13 00:56:23.517",ToDate:"2020-12-23 00:56:23.517" },
    OptionalFilter: { take: 50, page: 0, sort: [{ field: "createDate", dir: "desc" }] }
  }
  this.accountingService.GetPaymentCustomers(param).subscribe(response => {
    if (response.success) {
      this.rowData = response.result;
      this.gridApi.setRowData(this.rowData);
    }
  });
}
onGridReady(params) {
  this.gridApi = params.api;
}
}
