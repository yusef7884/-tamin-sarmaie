import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentsIndexComponent } from './payments-index.component';

describe('PaymentsIndexComponent', () => {
  let component: PaymentsIndexComponent;
  let fixture: ComponentFixture<PaymentsIndexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentsIndexComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentsIndexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
