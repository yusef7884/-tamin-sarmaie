import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class AccountingService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetPaymentCustomers: "payment/GetPaymentCustomers",
    }

    GetPaymentCustomers(model:any) {
        return this.restService.post(model, this.api.GetPaymentCustomers);
    }    
}