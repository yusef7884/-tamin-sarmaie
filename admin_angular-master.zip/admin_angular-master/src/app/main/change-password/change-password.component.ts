import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { matchPassword } from '@app/shared/validation/matchPassword';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ChangePasswordService } from './change-password.service';

@Component({
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
  providers: [ChangePasswordService]
})
export class ChangePasswordComponent implements OnInit {

  oldPassword: '';
  newPassword: '';
  confirmPassword: '';
  changePasswordForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
    public activeModal: NgbActiveModal,
    private changePasswordService: ChangePasswordService,
    private toastr: ToastrService,
    private router: Router
  ) { }
  initialForm() {
    this.changePasswordForm = this.formBuilder.group({
      oldPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    },
     {
        validator: matchPassword('newPassword', 'confirmPassword')
      });
  }
  ngOnInit(): void {
    this.initialForm();
  }
  get changePassword(): any {
    return this.changePasswordForm.controls;
  }
  saveChanePassword() {
    const changePassword = this.changePasswordForm.value;
    const command = {
      entity: {
        oldPassword: changePassword.oldPassword,
        newPassword: changePassword.newPassword,
        confirmPassword: changePassword.confirmPassword
      }
    };
    this.changePasswordService.changePassword(command).subscribe((response: any) => {

      if (response.success) {
        localStorage.removeItem('authentication');
        this.toastr.success('رمز عبور با موفقیت تغییر کرد');
        this.activeModal.close();
        this.router.navigate(['login']);
      }
    });
  }
  cancel() {
    this.activeModal.close();
  }

}
