import { Injectable } from '@angular/core';
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class ChangePasswordService {

  constructor(private restService: HttpRestService) { }

  api = {
    changePasswordApi: 'account/changepassword'
  }

  changePassword(command: any) {
    return this.restService.post(command, this.api.changePasswordApi);
  }
}
