import {Component, OnInit} from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';
import {ProfileService} from '@app/main/profile/profile.service';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  profileDetail: FormGroup = new FormGroup({});
  public userId: number;
  public responseValue = {
    nationalCode: '',
    firstName: '',
    lastName: '',
    gender: '',
    mobile: '',
    email: '',
    userName: '',
    password: '',
    confirmPassword: '',
    fullName: ''
  };
  public param = {};

  constructor(
    private formBuilder: FormBuilder,
    private service: ProfileService,
    private activeModal: NgbActiveModal) {
  }

  ngOnInit(): void {
    this.service.getPartyInfo().subscribe(response => {
      this.responseValue = response.result;
      this.setPartyValue();
    });
    this.initialForm();
  }

  initialForm() {
    this.profileDetail = this.formBuilder.group({
      nationalCode: new FormControl('',
        [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
          this.nationalCodeValidation(),
        ]),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
      mobile: new FormControl('', Validators.required),
      fullName: new FormControl(''),
      email: new FormControl('', [
        Validators.required,
        Validators.email]),
      userName: new FormControl('', Validators.required)
    });
  }

  setPartyValue() {
    this.profileDetail.controls.nationalCode.setValue(this.responseValue.nationalCode);
    this.profileDetail.controls.firstName.setValue(this.responseValue.firstName);
    this.profileDetail.controls.lastName.setValue(this.responseValue.lastName);
    this.profileDetail.controls.gender.setValue(this.responseValue.gender);
    this.profileDetail.controls.email.setValue(this.responseValue.email);
    this.profileDetail.controls.mobile.setValue(this.responseValue.mobile);
    this.profileDetail.controls.userName.setValue(this.responseValue.userName);
    this.profileDetail.controls.fullName.setValue(this.responseValue.fullName);
  }

  updateUser() {
    const command = {
      entity: {
        nationalCode: this.profileDetail.get('nationalCode').value,
        mobile: this.profileDetail.get('mobile').value,
        firstName: this.profileDetail.get('firstName').value,
        lastName: this.profileDetail.get('lastName').value,
        email: this.profileDetail.get('email').value,
        userName: this.profileDetail.get('userName').value,
        gender: this.profileDetail.get('gender').value,
        fullName: this.profileDetail.get('fullName').value
      }
    };
    this.service.updateParty(command).subscribe((response: any) => {
    });
  }

  submitForm() {
  }

  cancel() {
    this.activeModal.close();
  }

  nationalCodeValidation(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const input = control.value;
      if (!/^\d{10}$/.test(input)
        || input === '0000000000'
        || input === '1111111111'
        || input === '2222222222'
        || input === '3333333333'
        || input === '4444444444'
        || input === '5555555555'
        || input === '6666666666'
        || input === '7777777777'
        || input === '8888888888'
        || input === '9999999999') {
        return {invalid: control.value};
      }
      const check = parseInt(input[9]);
      let sum = 0;
      let i;
      for (i = 0; i < 9; ++i) {
        sum += parseInt(input[i]) * (10 - i);
      }
      sum %= 11;
      return (sum < 2 && check === sum) || (sum >= 2 && check + sum === 11) ? null : {invalid: control.value};
    };
  }

}
