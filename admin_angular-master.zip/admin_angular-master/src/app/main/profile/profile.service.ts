import {HttpRestService} from '@app/core/httpRestService';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {FormControl, Validators} from '@angular/forms';

@Injectable({providedIn: 'root'})
export class ProfileService {
  constructor(private restService: HttpRestService) {
  }

  api = {
    getUserInfoApi: 'party/getpartyinfo',
    saveChangesApi: 'party/updateparty'
  };

  updateParty(command: any) {
    return this.restService.post(command, this.api.saveChangesApi);
  }

  getPartyInfo() {
    return this.restService.post({}, this.api.getUserInfoApi);
  }

}
