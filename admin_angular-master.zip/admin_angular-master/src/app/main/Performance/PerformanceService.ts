import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class PerformanceService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetRunSpData: "marketdata/GetRunSpData",
    }

    GetRunSpData(model:any,Spname:string) {
        return this.restService.post(model, this.api.GetRunSpData+Spname);
    }    
}