export class GetNewsUsersModel {
    Isin?: string;
    CountNews?: number;
    CountUsers?: number;
    SymbolFa?: string;
    LastNews?: any;
}