import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsUsersComponent } from './news-users.component';

describe('NewsUsersComponent', () => {
  let component: NewsUsersComponent;
  let fixture: ComponentFixture<NewsUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewsUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
