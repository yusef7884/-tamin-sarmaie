import { Component, OnInit } from '@angular/core';
import { ButtonRendererComponent } from '@app/shared/ButtonRenderer/ButtonRendererComponent';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GetNewsUsersModel } from '../PerformanceModel';
import { PerformanceService } from '../PerformanceService';

@Component({
  selector: 'app-news-users',
  templateUrl: './news-users.component.html',
  styleUrls: ['./news-users.component.css'],
  providers: [PerformanceService]
})
export class NewsUsersComponent implements OnInit {
  rowData: GetNewsUsersModel[] = [];
  frameworkComponents: any;
  public localeText = {
    page: "صفحه",
    More: "بیشتر",
    to: "تا",
    of: "از",
    next: "صفحه بعد",
    last: "صفحه قبل",
    first: "ابتدا",
    previous: "صفحه قبل",
    loadingOoo: "درحال فراخوانی...",
    selectAll: "Query all",
    searchOoo: "query...",
    blanks: "blank",
    filterOoo: "فیلتر...",
    applyFilter: "daApplyFilter...",
    equals: "مساوی",
    notEqual: "نا مساوی",
    lessThan: "کمتر از",
    greaterThan: "بیشتر از",
    lessThanOrEqual: "کمتر یا مساوی با",
    greaterThanOrEqual: "بیشتر یا مساوی با",
    inRange: "در بازه",
    contains: "شامل",
    notContains: "شامل نباشد",
    startsWith: "شروع شود با",
    endsWith: "پایان یابد با",
    Group: "گروه",
    columns: "ستونها",
    filters: "فیلتر",
    rowGroupColumns: "ستونهای گروهی",
    rowGroupColumnsEmptyMessage: "ستونهای گروهی خالی هستند",
    valueColumns: "مقادیر ستونها",
    pivotMode: "حالت پیوت",
    groups: "گروهها",
    values: "مقدار",
    pivots: "پیوت",
    valueColumnsEmptyMessage: "خالی",
    pivotColumnsEmptyMessage: "خالی",
    toolPanelButton: "کلید پنل ابزار",
    noRowsToShow: "هیج دیتای برای نمایش وجود ندارد",
    pinColumn: "ستون پین شده",
    valueAggregation: "مجموع",
    autosizeThiscolumn: "ستون تغییر اندازه پذیر",
    autosizeAllColumns: "ستونهای قابل تغییر اندازه",
    groupBy: "مرتب سازی",
    ungroupBy: "نامرتب سازی",
    resetColumns: "ریست کردن ستون",
    expandAll: "گسترش دادن همه",
    collapseAll: "جمع کردن",
    toolPanel: "ابزار ",
    export: "خروجی گرفتن",
    csvExport: "خروجی گرفتن با فرمت csv",
    excelExport: "ارسال به اکسل",
    pinLeft: "پین &lt;&lt;",
    pinRight: "پین &gt;&gt;",
    noPin: "بدون پین &lt;&gt;",
    sum: "جمع",
    min: "کمترین",
    max: "بیشترین",
    none: "هیچکدام",
    count: "تعداد",
    average: "میانگین",
    copy: "کپی",
    copyWithHeaders: "کپی همراه با هدر",
    ctrlC: "ctrl + C",
    paste: "چسپاندن",
    ctrlV: "ctrl + V",
  };

  columnDefs = [
    {
      headerName: "تاریخ",
      flex: 1,
      minWidth: 100,
      field: "LastNews",
      headerTooltip: "تاریخ",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "نماد",
      flex: 1,
      minWidth: 100,
      field: "SymbolFa",
      headerTooltip: "نماد",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "تعداد کاربران",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "CountUsers",
      headerTooltip: "تعداد کاربران",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "تعداد اخبار",
      flex: 1,
      minWidth: 200,
      width: 200,
      field: "CountNews",
      headerTooltip: "تعداد اخبار",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      },
    },
    {
      headerName: "Isin",
      flex: 1,
      minWidth: 100,
      width: 100,
      field: "Isin",
      headerTooltip: "Isin",
      sortable: true,
      filterParams: {
        newRowsAction: "keep",
      }
    }


  ];
  public noRowsTemplate: string;
  public loadingTemplate: string;
  private gridApi;



  constructor(private modalService: NgbModal,
    private performanceService: PerformanceService
  ) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }

  ngOnInit(): void {
    this.loadingTemplate = `<span class="ag-overlay-loading-center">لطفا صبر کنید...</span>`;
    this.noRowsTemplate = `<span>هیج دیتای برای نمایش وجود ندارد</span>`;

    this.LoadData();
  }
  LoadData() {
    var param = {
      reportFilter: { Entity: "IRO1FOLD0001,IRO1MSMI0001" },
      OptionalFilter: { take: 50, page: 0, sort: [{ field: "created", dir: "desc" }] }
    }
    this.performanceService.GetRunSpData(param, '?spname=dbo.JsonGetNewsUsers&spparams=%27%27').subscribe(response => {
      if (response.success) {
        this.rowData =JSON.parse(response.result);
        this.gridApi.setRowData(this.rowData);
      }
    });
  }
  onGridReady(params) {
    this.gridApi = params.api;
  }
}
