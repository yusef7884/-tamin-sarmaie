export class  NewsModel {
    abstract?: string;
    created?: any;
    createdBy?: string;
    createdJalaliDate?: string;
    description?: string;
    eventDate?: any;
    eventJalaiDate?: string;
    id?:  number;
    importantType?:  number;
    importantTypeTitle?: string;
    internalMessage?: string;
    isin?: string;
    link?:string;
    modified?: any;
    modifiedBy?: string;
    modifiedJalaiDate?: string;
    newsType?:  number;
    newsTypeTitle?: string;
    operatorType?:  number;
    operatorTypeTitle?: string;
    reference?: string;
    status?: number;
    statusTitle?: string;
    symbol?: string;
    title?: string;
}

