import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class NewsService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetNews: "News/GetNews",
        GetNewsById: "News/GetNewsById",
        SaveNews:"News/SaveNews",
        ChangeStatusNews:"News/ChangeStatusNews",
    }

    GetNews(model:any) {
        return this.restService.post(model, this.api.GetNews);
    }

    GetNewsById(model:any) {
        return this.restService.post(model, this.api.GetNewsById);
    }
    SaveNews(model:any) {
        return this.restService.post(model, this.api.SaveNews);
    }
    ChangeStatusNews(model:any) {
        return this.restService.post(model, this.api.ChangeStatusNews);
    }
    
}