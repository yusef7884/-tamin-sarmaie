import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { InstrumentsService } from '@app/core/InstrumentsService';
import { SharedDataService } from '@app/core/sharedDataService';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NewsModel } from '../News.Model';
import { NewsService } from '../NewsService';

@Component({
  selector: 'app-news-add',
  templateUrl: './news-add.component.html',
  styleUrls: ['./news-add.component.css'],
  providers: [InstrumentsService, SharedDataService, NewsService]
})
export class NewsAddComponent implements OnInit {
  
  news: Partial<NewsModel> = {};
  Instruments: any[]; //سهم
  filteredInstruments: any[];
  SelectedInstrument: any;

  NewsTypes: any[];
  ImportantTypes: any[];
  OperatorTypes: any[];


  oldPassword: '';
  newPassword: '';
  confirmPassword: '';
  Checked: false;
  frm: FormGroup;
  constructor(private activeModal: NgbActiveModal,
    private instrumentsService: InstrumentsService,
    private sharedDataService: SharedDataService,
    private newsService: NewsService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.LoadData();
    this.initialForm();
  }

  LoadData() {
    this.instrumentsService.GetInstrumentsList().subscribe(response => {

      if (response.success) {
        this.Instruments = response.result;
      }
    });
    this.sharedDataService.NewsTypeEnum().subscribe(response => {

      if (response.success) {
        this.NewsTypes = response.result;
      }
    });
    this.sharedDataService.ImportantTypeEnum().subscribe(response => {

      if (response.success) {
        this.ImportantTypes = response.result;
      }
    });
    this.sharedDataService.OperatorTypeEnum().subscribe(response => {

      if (response.success) {
        this.OperatorTypes = response.result;
      }
    });

  }
  initialForm() {
    if (this.news) {
      this.frm = this.formBuilder.group({

        operatorType: ['', Validators.required],
        importantType: ['', Validators.required],
        instrument: [''],
        newsType: ['', Validators.required],
        title: ['', Validators.required],
        abstract: ['', Validators.required],
        description: [''],
        internalMessage: [],
        reference: [''],
        link: ['']
      });
      this.frm.valueChanges.subscribe(newValue => {
        if (this.Instruments) {
          this.filteredInstruments = this.Instruments.filter(value => value.symbolFa.indexOf(newValue.instrument) === 0);
        }
      })
    }
    this.frm.controls['newsType'].valueChanges
      .subscribe(value => {
        if (value == 1) {
          this.frm.controls['instrument'].setValidators(Validators.required);
          this.frm.controls['instrument'].updateValueAndValidity();
        } else {
          this.frm.controls['instrument'].setValidators([]);
          this.frm.controls['instrument'].updateValueAndValidity();
        }
      });
  }
  setNewsInstruments(Option: any) {
    this.SelectedInstrument = Option;
  }
  Save() {
    if (this.frm.valid) {
      if (this.frm.controls.newsType.value == 2) {
        this.SelectedInstrument = { isin: { isin: null }, symbolFa: null }
      }
      var param = {
        entity:
        {
          id: this.news.id,
          operatorType: this.frm.controls.operatorType.value,
          newsType: this.frm.controls.newsType.value,
          acceptedReject: false,
          internalMessage: this.frm.controls.internalMessage.value,
          link: this.frm.controls.link.value,
          description: this.frm.controls.description.value,
          abstract: this.frm.controls.abstract.value,
          title: this.frm.controls.title.value,
          isin: this.SelectedInstrument.isin.isin,
          symbol: this.SelectedInstrument.symbolFa,
          eventDate: null,
          created: this.news.created,
          createdBy: "Admin",
          importantType: this.frm.controls.importantType.value,
          status: this.news.status,
          reference: this.frm.controls.reference.value
        }
      }
      this.newsService.SaveNews(param).subscribe(response => {
        if (response.success) {
          this.activeModal.close();
        }
      });

    }
  }
  cancel() {
    this.activeModal.close();
  }
  OpenLink() {
    if (this.frm.controls.link.value) {
      window.open(this.frm.controls.link.value, "_blank");
    }
  }
  ChangeNewsStatus(NewStatus: number) {
    if (this.news.status === NewStatus) {
      NewStatus = 3;
    }
    var param = { entity: { id: this.news.id, status: NewStatus } }
    this.newsService.ChangeStatusNews(param).subscribe(response => {
      if (response.success) {
        this.news.status = NewStatus;
      }
    });
  }

}