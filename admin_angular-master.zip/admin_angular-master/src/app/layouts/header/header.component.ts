import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RegisterComponent } from '../register/register.component';

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"],
  encapsulation: ViewEncapsulation.None
})

export class HeaderComponent implements OnInit {

  constructor(private router: Router, private modalService: NgbModal) { }

  ngOnInit() { }

  userLogin() {
    this.router.navigate(["login"]);
  }

  registerUser() {
    const modalRef = this.modalService.open(RegisterComponent);

  }

}
