import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ContactUsService } from './contact-us.service';


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss'],
  providers: [ContactUsService]
})
export class ContactUsComponent implements OnInit {
  addressForm: FormGroup;

  constructor(private fb: FormBuilder, private service: ContactUsService, private ts: ToastrService) { }

  ngOnInit() {
    this.initialForm();
  }
  initialForm() {
    this.addressForm = this.fb.group({
      fullName: new FormControl('', Validators.required),
      title: new FormControl('', Validators.required),
      mobile: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
      clientValue: new FormControl('', Validators.required),
    });
  }

  get address(): any {
    return this.addressForm.controls;
  }
  registerUser() {
    let address = this.addressForm.value;
    let command = {
      entity: {
        fullName: address.fullName,
        title: address.title,
        mobile: address.mobile,
        email: address.email,
        description: address.description

      }
    }
    this.service.saveMessage(command).subscribe((response: any) => {
      if (response.success) {
        this.ts.success("پیغام شما ذخیره شد")
      }
    })
  }

}