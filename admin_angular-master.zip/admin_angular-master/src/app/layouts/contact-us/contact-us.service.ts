import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class ContactUsService {
    constructor(private restService: HttpRestService) { }

    api = {
        saveMessage: "message/savemessage",
      
    }
    saveMessage(command:any){
        return this.restService.post(command, this.api.saveMessage);
    }
    
}