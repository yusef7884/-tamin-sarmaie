import { RouterModule } from "@angular/router";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FooterComponent } from "./footer/footer.component";
import { HeaderComponent } from "./header/header.component";
import { BodyComponent } from "./body/body.component";
import { RegisterComponent } from './register/register.component';
import { SharedModule } from '@app/shared/shared.module';
import { ContactUsComponent } from './contact-us/contact-us.component';

@NgModule({
  declarations: [
    BodyComponent,
    HeaderComponent,
    FooterComponent,
    RegisterComponent,
    ContactUsComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SharedModule
    
  ],
  entryComponents: [
    RegisterComponent
  ]
})
export class LayoutsModule { }
