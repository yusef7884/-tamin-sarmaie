import { Injectable } from '@angular/core';
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class RegisterService {
    constructor(private restService: HttpRestService) { }

    api = {
        getCaptchaApi: 'captcha/getcaptcha',
        getChallengeCodeApi: 'party/partysendchallengecode',
        checkChallengeCodeApi: 'party/partycheckchallengecode',
        registerUserApi: 'party/registerparty'
      };
    
      getCaptcha() {
        return this.restService.post(null, this.api.getCaptchaApi);
      }
    
      getChallengeCode(command: any) {
        return this.restService.post(command, this.api.getChallengeCodeApi);
      }
    
      partyCheckChallengeCode(command: any) {
        return this.restService.post(command, this.api.checkChallengeCodeApi);
      }
    
      registerParty(command: any) {
        return this.restService.post(command, this.api.registerUserApi);
      }

    
}