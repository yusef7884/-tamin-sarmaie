import { Component, OnInit } from '@angular/core';
import {
    AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators
} from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { RegisterService } from './register.service';


@Component({
    selector: "app-register",
    templateUrl: "./register.component.html",
    styleUrls: ["./register.component.scss"],
    providers: [RegisterService]
})

export class RegisterComponent implements OnInit {

    getNationalCodeFlag = true;
    getChallengeCodeFlag = false;
    getUserDataFlag = false;
    registerDoneFlag = false;
    getNationalCodeForm: FormGroup;
    submitChallengeFlg = false;
    captchaInfo: any = {};
    timeLeft = 180;
    timeInMinute: number;
    timeLeftPercent: number;
    timeLeftFlag = true;
    interval = null;

    constructor(private fBuilder: FormBuilder,
        private service: RegisterService,
        private activeModal: NgbActiveModal,
        private toastr: ToastrService
    ) {
    }

    ngOnInit(): void {
        this.getCaptcha();
        this.initialgetNationalCodeForm();

    }

    initialgetNationalCodeForm() {
        this.getNationalCodeForm = this.fBuilder.group({
            nationalCode: new FormControl('', [
                Validators.required,
                this.nationalCodeValidation()]),
            mobile: new FormControl('', [
                Validators.required,
                this.phoneNumberValidation()
            ]),
            challengeCode: new FormControl('', [
                Validators.maxLength(5),
                Validators.minLength(5),
                Validators.required]),
            clientValue: new FormControl('', [
                Validators.required,
                Validators.maxLength(4)]),
            firstName: new FormControl('', Validators.required),
            lastName: new FormControl('', Validators.required),
            email: new FormControl('', Validators.required),
            userName: new FormControl('', Validators.required),
            password: new FormControl('', [
                Validators.required,
                Validators.minLength(7)]),
            confirmPassword: new FormControl('', [
                Validators.required,
                Validators.minLength(7),
                this.confirmPass()])
        });
    }

    submitNationalCode() {
        if (this.getNationalCodeForm.get('nationalCode').invalid ||
            this.getNationalCodeForm.get('mobile').invalid ||
            this.getNationalCodeForm.get('clientValue').invalid) {
            return;
        } else {
            const command = {
                entity: {
                    nationalCode: this.getNationalCodeForm.get('nationalCode').value,
                    mobile: '09' + this.getNationalCodeForm.get('mobile').value,
                    captchaClientModel: {
                        salt: this.captchaInfo.salt,
                        hashed: this.captchaInfo.hashCode,
                        clientValue: this.getNationalCodeForm.get('clientValue').value
                    }
                }
            };
            this.service.getChallengeCode(command).subscribe((response: any) => {
                if (response.success) {
                    if (response.result.responseCode !== 1) {
                        this.toastr.error(response.result.message);
                        this.getCaptcha();
                    } else {
                        
                        this.getNationalCodeFlag = false;
                        this.getChallengeCodeFlag = true;
                        this.timeLeft = 180;
                        this.timeLeftPercent = 0;
                        this.startTimer();
                    }
                }
            });
        }
    }

    submitChallengeCode() {
        if (this.getNationalCodeForm.get('challengeCode').invalid) {
            return;
        } else {
            const command = {
                entity: {
                    nationalCode: this.getNationalCodeForm.get('nationalCode').value,
                    challengeCode: this.getNationalCodeForm.get('challengeCode').value
                }
            };
            this.service.partyCheckChallengeCode(command).subscribe((response => {
                if (response.success) {
                    if (response.result.responseCode !== 1) {
                        this.toastr.error(response.result.message);
                    } else {
                        this.submitChallengeFlg = true;
                        this.getNationalCodeFlag = false;
                        this.getChallengeCodeFlag = false;
                        this.getNationalCodeForm.get('clientValue').reset();
                        this.getCaptcha();
                        this.getUserDataFlag = true;
                    }

                }
            }));
        }
    }

    registerUser() {
        if (this.getNationalCodeForm.invalid) {
            return;
        } else {
            const command = {
                entity: {
                    nationalCode: this.getNationalCodeForm.get('nationalCode').value,
                    phoneNumber: '09' + this.getNationalCodeForm.get('mobile').value,
                    firstName: this.getNationalCodeForm.get('firstName').value,
                    lastName: this.getNationalCodeForm.get('lastName').value,
                    email: this.getNationalCodeForm.get('email').value,
                    userName: this.getNationalCodeForm.get('userName').value,
                    password: this.getNationalCodeForm.get('password').value,
                    confirmPassword: this.getNationalCodeForm.get('confirmPassword').value,
                    captchaClientModel: {
                        salt: this.captchaInfo.salt,
                        hashed: this.captchaInfo.hashCode,
                        clientValue: this.getNationalCodeForm.get('clientValue').value
                    }

                }
            };
            this.service.registerParty(command).subscribe((response: any) => {
                if (response.success) {
                    this.getUserDataFlag = false;
                    this.activeModal.close();
                    this.toastr.success('ثبت نام با موفقیت انجام شد');
                }
            });
        }
    }

    nationalCodeValidation(): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const input = control.value;
            if (!/^\d{10}$/.test(input)
                || input === '0000000000'
                || input === '1111111111'
                || input === '2222222222'
                || input === '3333333333'
                || input === '4444444444'
                || input === '5555555555'
                || input === '6666666666'
                || input === '7777777777'
                || input === '8888888888'
                || input === '9999999999') {
                return { invalid: control.value };
            }
            const check = parseInt(input[9]);
            let sum = 0;
            let i;
            for (i = 0; i < 9; ++i) {
                sum += parseInt(input[i]) * (10 - i);
            }
            sum %= 11;
            return (sum < 2 && check === sum) || (sum >= 2 && check + sum === 11) ? null : { invalid: control.value };
        };
    }

    confirmPass(): ValidatorFn {
        return (c: AbstractControl): ValidationErrors | null => {
            const verifyPassword = c.value;
            if (verifyPassword) {
                const root = c.root as FormGroup;
                const confirmPassword = root.get('password').value;

                if (verifyPassword !== confirmPassword) {
                    return { PasswordVerify: true };
                }
            }

            return null;
        };

    }

    phoneNumberValidation(): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const mobilePattern = '^[0|1|2|3|9][0-9]{8}$';
            return control.value.match(mobilePattern) ? null : { invalid: control.value };
        };
    }
    cancel() {
        if (this.getChallengeCodeFlag) {
            clearInterval(this.interval);
        }
        this.activeModal.close();
    }

    getCaptcha() {
        this.service.getCaptcha().subscribe((response): any => {
            this.captchaInfo = response;
        });
    }

    startTimer() {
        this.interval = setInterval(() => {
            if (this.timeLeft > 0) {
                this.timeLeft--;
                this.timeInMinute = Math.floor(this.timeLeft / 60);
                this.timeLeftPercent = Math.abs(((180 - this.timeLeft) * 100) / 180);
                if (this.submitChallengeFlg) {
                    clearInterval(this.interval);
                }
            } else {
                clearInterval(this.interval);
                this.showToastr();
                this.getNationalCodeFlag = true;
                this.getChallengeCodeFlag = false;
                this.timeLeftFlag = false;
            }
        }, 1000);

    }

    showToastr() {
        this.getNationalCodeForm.get('clientValue').reset();
        this.getCaptcha();
        this.toastr.warning('زمان شما برای وارد کردن کد تمام شده است. مجددا تلاش نمایید');
    }


}