import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { IdlePreloadModule } from 'angular-idle-preload';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpRestService } from './core/httpRestService';
import { AppRoutingModule } from './app-routing.module';
import { MainModule } from './main/main.module';
import { LayoutsModule } from './layouts/layouts.module';
import { DatePipe } from '@angular/common';
import { AuthService } from './shared/authentication/auth.service';
import { AuthInterceptor } from './shared/authentication/auth.interceptor';
import { SharedModule } from './shared/shared.module';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    IdlePreloadModule.forRoot(),
    LayoutsModule,
    MainModule,
    AppRoutingModule,
    HttpClientModule,
    SharedModule,
    ToastrModule.forRoot({
      positionClass: 'toast-bottom-left',
      messageClass: 'text-right'
    })
  ],
  providers: [
    HttpRestService, 
    AuthService, 
    DatePipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass:AuthInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
