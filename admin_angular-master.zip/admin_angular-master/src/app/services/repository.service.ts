import { Injectable } from '@angular/core';
import { AuthService } from '@app/shared/authentication/auth.service';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { HttpRestService } from '@app/core/httpRestService';
import { Router } from '@angular/router';
import { MainService } from '@app/main/main.service';

@Injectable()
export class RepositoryService {
    constructor(private restService: HttpRestService,
        private authService: AuthService, private router: Router, private mainService: MainService) { }
    private allPages = [];
    private userInfo = {
        id: ''
    };
    private userSubject = new BehaviorSubject<any>(this.userInfo);

    pages = {

        getAllpages: () => {
            return this.allPages;
        },
        accessToPageByService: (pageUrl: string): Observable<any> => {
            let subject = new Subject<any>();
            if (this.allPages.length === 0) {
                let allPages = this.getAccessPagesByService();
                allPages.subscribe((res) => {
                    let findPage = res.filter(page => { return page.pageLink === pageUrl })[0];
                    if (findPage) {
                        subject.next({ date: Date.now(), value: true });
                    }
                })
            }
            return subject.asObservable();
        },

        accessToPageWithoutService: (pageUrl: string): boolean => {
            let isAuthenticated = false;
            let findPage = this.allPages.filter(page => { return page.pageLink === pageUrl })[0];
            if (findPage) {
                isAuthenticated = true;
            }
            return isAuthenticated;
        }
    };

    user = {
        getUser: (): Observable<any> => {
            if (this.userInfo.id == '') {
                return this.getUserInformation();
            } else {
                return this.user.getUserInfo();
            }
        },
        setUser: (user: any) => {
            this.userInfo = user;
            this.userSubject.next(this.userInfo);
        },
        getUserInfo: (): Observable<any> => {
            return this.userSubject;
        },
        removeUser: () => {
            this.userInfo = { id: '' };
        }
    }

    private getUserInformation = (): Observable<any> => {
        let subject = new BehaviorSubject<any>(this.userInfo);
        this.mainService.getUserInformation().subscribe(response => {
            if (response.success) {
                this.user.setUser(response.result)
                subject.next(this.userInfo);
            }
        });
        return subject.asObservable();
    }

    private getAccessPagesByService = (): Observable<Array<any>> => {
        if (localStorage.getItem("authentication")) {
            let token = localStorage.getItem("authentication");
            this.restService.addHeader('Authorization', 'Bearer ' + token);
            let subject = new BehaviorSubject<Array<any>>(this.allPages);
            this.authService.getAllPageAccessByUserName().subscribe(response => {
                if (response.success) {
                    this.allPages = response.result;
                    subject.next(this.allPages);
                }
            });
            return subject.asObservable();
        } else {
            this.router.navigate(['/']);
        }


    }













}