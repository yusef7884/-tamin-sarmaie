import { Injectable } from '@angular/core';
import { HttpRestService } from '@app/core/httpRestService';

@Injectable({providedIn: 'root'})
export class CommonService {
    constructor(private restService: HttpRestService) { }
    
    api = {
        getInstrumentsByPartyIdApi: "MarketData/GetInstrumentsByPartyId"
    }

    getInstrumentsByPartyId(command: any) {
        return this.restService.post(command, this.api.getInstrumentsByPartyIdApi);
    }
}