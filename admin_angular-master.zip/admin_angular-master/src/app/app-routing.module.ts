import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { IdlePreload } from "angular-idle-preload";

import { LoginComponent } from "./login/login.component";
import { BodyComponent } from './layouts/body/body.component';
import { ContactUsComponent } from './layouts/contact-us/contact-us.component';

@NgModule({
  imports: [
    RouterModule.forRoot(
      [
        {
          path: "login",
          component: LoginComponent
        },
        {
          path: "contact-us",
          component: ContactUsComponent
        },
        {
          path: "",
          component: BodyComponent
        }
      ],
      { preloadingStrategy: IdlePreload }
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
