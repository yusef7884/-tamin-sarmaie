import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class InstrumentsService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetInstrumentsList: "instrument/GetInstrumentsList"
    }

    GetInstrumentsList() {
        return this.restService.get(null,this.api.GetInstrumentsList);
    }
}