import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class SharedDataService {
    constructor(private restService: HttpRestService) { }

    api = {
        NewsTypeEnum: "sharedData/NewsTypeEnum",
        OperatorTypeEnum: "sharedData/OperatorTypeEnum",
        ImportantTypeEnum: "sharedData/ImportantTypeEnum",
        
    }

    NewsTypeEnum() {
        return this.restService.get(null,this.api.NewsTypeEnum);
    }

    OperatorTypeEnum() {
        return this.restService.get(null,this.api.OperatorTypeEnum);
    }

    ImportantTypeEnum() {
        return this.restService.get(null,this.api.ImportantTypeEnum);
    }
}