import { RavandDto } from './ravand-dto';
import { Injectable, EventEmitter } from '@angular/core';
import * as signalR from '@aspnet/signalr';
import { environment } from 'src/environments/environment';
import { RealLegalDto } from './real-legal-dto';
import { ShortList_SahamDto } from './short-list-sahm-dto';
import { ShortList_AkhzaDto } from './short-list-akhza-dto';
import { ShortList_CapRaiseDto } from './short-list-capraise-dto';
import { ShortList_HajmDto } from './short-list-hajm-dto';
import { ShortList_IndustryDto } from './short-list-industry-dto';
import { ShortList_IPODto } from './short-list-ipo-dto';
import { ShortList_OptionDto } from './short-list-option-dto';
import { ShortList_OraghDto } from './short-list-oragh-dto';
import { ShortList_PairDto } from './short-list-pair-dto';
import { ShortList_PayeDto } from './short-list-paye-dto';
import { ShortList_SandoghDto } from './short-list-sandogh-dto';
import { ShortList_SarkhatiDto } from './short-list-sarkhati-dto';
import { ShortList_SarmaDto } from './short-list-sarma-dto';
import { ShortList_StoRightDto } from './short-list-storight-dto';
import { ShortList_TesehDto } from './short-list-teseh-dto';

@Injectable({
  providedIn: 'root'
})
export class SignalRService {
  private hubConnection: signalR.HubConnection;
  private hubConnectionShortListSaham: signalR.HubConnection;
  private hubConnectionShortListAkhza: signalR.HubConnection;
  private hubConnectionShortListIndustry: signalR.HubConnection;
  private hubConnectionShortListOption: signalR.HubConnection;
  private hubConnectionShortListOragh: signalR.HubConnection;
  private hubConnectionShortListSandogh: signalR.HubConnection;
  private hubConnectionShortListSarkhati: signalR.HubConnection;
  private hubConnectionShortListTeseh: signalR.HubConnection;

  private hubConnectionShortListCapRaise: signalR.HubConnection;
  private hubConnectionShortListHajm: signalR.HubConnection;
  private hubConnectionShortListIPO: signalR.HubConnection;
  private hubConnectionShortListPair: signalR.HubConnection;
  private hubConnectionShortListPaye: signalR.HubConnection;
  private hubConnectionShortListSarma: signalR.HubConnection;
  private hubConnectionShortListStoRight: signalR.HubConnection;

  anotherSignalReceived = new EventEmitter<number>();
  realLegalSignalReceived = new EventEmitter<RealLegalDto>();
  shortListSahamSignalReceived = new EventEmitter<ShortList_SahamDto[]>();
  shortListAkhzaSignalReceived = new EventEmitter<ShortList_AkhzaDto[]>();
  shortListIndustrySignalReceived = new EventEmitter<ShortList_IndustryDto[]>();
  shortListOptionSignalReceived = new EventEmitter<ShortList_OptionDto[]>();
  shortListOraghSignalReceived = new EventEmitter<ShortList_OraghDto[]>();
  shortListSandoghSignalReceived = new EventEmitter<ShortList_SandoghDto[]>();
  shortListSarkhatiSignalReceived = new EventEmitter<ShortList_SarkhatiDto[]>();
  shortListTesehSignalReceived = new EventEmitter<ShortList_TesehDto[]>();
  shortListStoRightSignalReceived = new EventEmitter<ShortList_StoRightDto[]>();
  shortListSarmaSignalReceived = new EventEmitter<ShortList_SarmaDto[]>();
  shortListPayeSignalReceived = new EventEmitter<ShortList_PayeDto[]>();
  shortListPairSignalReceived = new EventEmitter<ShortList_PairDto[]>();
  shortListIPOSignalReceived = new EventEmitter<ShortList_IPODto[]>();
  shortListHajmSignalReceived = new EventEmitter<ShortList_HajmDto[]>();
  shortListCapRaiseSignalReceived = new EventEmitter<ShortList_CapRaiseDto[]>();

  ravandSignalReceived = new EventEmitter<RavandDto>();
  
  constructor() {
    // this.buildConnection();
    // this.startConnection();

    // //RealLegal
    // this.buildConnectionRealLegal();
    // this.startConnectionRealLegal();

 

    //ShortListSaham
    this.buildConnectionShortListSaham();
    this.startConnectionShortListSaham();

    //ShortListAkhza
    this.buildConnectionShortListAkhza();
    this.startConnectionShortListAkhza();

    //ShortListIndustry
    this.buildConnectionShortListIndustry();
    this.startConnectionShortListIndustry();

    //ShortListOption
    this.buildConnectionShortListOption();
    this.startConnectionShortListOption();

    //ShortListOragh
    this.buildConnectionShortListOragh();
    this.startConnectionShortListOragh();

    //ShortListSandogh
    this.buildConnectionShortListSandogh();
    this.startConnectionShortListSandogh();

    //ShortListSarkhati
    this.buildConnectionShortListSarkhati();
    this.startConnectionShortListSarkhati();

    //ShortListTeseh
    this.buildConnectionShortListTeseh();
    this.startConnectionShortListTeseh();

    //ShortListCapRaise
    this.buildConnectionShortListCapRaise();
    this.startConnectionShortListCapRaise();
  
    //ShortListHajm
    this.buildConnectionShortListHajm();
    this.startConnectionShortListHajm();

    //ShortListIPO
    this.buildConnectionShortListIPO();
    this.startConnectionShortListIPO();

    //ShortListPair
    this.buildConnectionShortListPair();
    this.startConnectionShortListPair();

    //ShortListPaye
    this.buildConnectionShortListPaye();
    this.startConnectionShortListPaye();

    //ShortListStoRight
    this.buildConnectionShortListStoRight();
    this.startConnectionShortListStoRight();

}

  public buildConnection = () => {
    this.hubConnection = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/signalHub")
      .build();
  };

  public buildConnectionShortListSaham = () => {
    this.hubConnectionShortListSaham = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListSahamHub")
      .build();
  };

  public buildConnectionShortListAkhza = () => {
    this.hubConnectionShortListAkhza = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListAkhzaHub")
      .build();
  };

  public buildConnectionShortListIndustry = () => {
    this.hubConnectionShortListIndustry = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListIndustryHub")
      .build();
  };

  public buildConnectionShortListOption = () => {
    this.hubConnectionShortListOption = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListOptionHub")
      .build();
  };

  public buildConnectionShortListOragh = () => {
    this.hubConnectionShortListOragh = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListOraghHub")
      .build();
  };

  public buildConnectionShortListSandogh = () => {
    this.hubConnectionShortListSandogh = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListSandoghHub")
      .build();
  };

  public buildConnectionShortListSarkhati = () => {
    this.hubConnectionShortListSarkhati = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListSarkhatiHub")
      .build();
  };

  public buildConnectionShortListTeseh = () => {
    this.hubConnectionShortListTeseh = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListTesehHub")
      .build();
  };

  
  public buildConnectionShortListCapRaise = () => {
    this.hubConnectionShortListCapRaise = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListCapRaiseHub")
      .build();
  };

  public buildConnectionShortListHajm = () => {
    this.hubConnectionShortListHajm = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListHajmHub")
      .build();
  };

  public buildConnectionShortListIPO = () => {
    this.hubConnectionShortListIPO = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListIPOHub")
      .build();
  };

  public buildConnectionShortListPair = () => {
    this.hubConnectionShortListPair = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListPairHub")
      .build();
  };

  public buildConnectionShortListPaye = () => {
    this.hubConnectionShortListPaye = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListPayeHub")
      .build();
  };

  public buildConnectionShortListSarma = () => {
    this.hubConnectionShortListSarma = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListSarmaHub")
      .build();
  };

  public buildConnectionShortListStoRight = () => {
    this.hubConnectionShortListStoRight = new signalR.HubConnectionBuilder()
      .withUrl(environment.signalRApiBaseUrl + "/shortListStoRightHub")
      .build();
  };

  // public startConnection = () => {
  //   this.hubConnection
  //     .start()
  //     .then(() => {
  //       console.log("Connection Started ...");
  //       this.registerAnotherSignalEvents();
  //     })
  //     .catch((err) => {
  //       console.log("Error while starting connection:" + err);
  //       setTimeout(() => {
  //         this.startConnection();
  //       }, 3000);
  //     });
  // };

  // public startConnectionRealLegal = () => {
  //   this.hubConnectionRealLegal
  //     .start()
  //     .then(() => {
  //       console.log("Connection to RealLegal Started ...");
  //       this.registerRealLegalSignalEvents();
  //     })
  //     .catch((err) => {
  //       console.log("Error while starting realLegal connection:" + err);
  //       setTimeout(() => {
  //         this.startConnectionRealLegal();
  //       }, 3000);
  //     });
  // };



  public startConnectionShortListSaham = () => {
    this.hubConnectionShortListSaham
      .start()
      .then(() => {
        console.log("Connection to ShortListSaham Started ...");
        this.registerShortListSahamSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListSaham connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListSaham();
        }, 3000);
      });
  };

  public startConnectionShortListAkhza = () => {
    this.hubConnectionShortListAkhza
      .start()
      .then(() => {
        console.log("Connection to ShortListAkhza Started ...");
        this.registerShortListAkhzaSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListAkhza connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListAkhza();
        }, 3000);
      });
  };

  public startConnectionShortListIndustry = () => {
    this.hubConnectionShortListIndustry
      .start()
      .then(() => {
        console.log("Connection to ShortListIndustry Started ...");
        this.registerShortListIndustrySignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListIndustry connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListIndustry();
        }, 3000);
      });
  };

  public startConnectionShortListOption = () => {
    this.hubConnectionShortListOption
      .start()
      .then(() => {
        console.log("Connection to ShortListOption Started ...");
        this.registerShortListOptionSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListOption connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListOption();
        }, 3000);
      });
  };

  public startConnectionShortListOragh = () => {
    this.hubConnectionShortListOragh
      .start()
      .then(() => {
        console.log("Connection to ShortListOragh Started ...");
        this.registerShortListOraghSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListOragh connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListOragh();
        }, 3000);
      });
  };

  public startConnectionShortListSandogh = () => {
    this.hubConnectionShortListSandogh
      .start()
      .then(() => {
        console.log("Connection to ShortListSandogh Started ...");
        this.registerShortListSandoghSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListSandogh connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListSandogh();
        }, 3000);
      });
  };

  public startConnectionShortListSarkhati = () => {
    this.hubConnectionShortListSarkhati
      .start()
      .then(() => {
        console.log("Connection to ShortListSarkhati Started ...");
        this.registerShortListSarkhatiSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListSarkhati connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListSarkhati();
        }, 3000);
      });
  };

  public startConnectionShortListTeseh = () => {
    this.hubConnectionShortListTeseh
      .start()
      .then(() => {
        console.log("Connection to ShortListTeseh Started ...");
        this.registerShortListTesehSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListTeseh connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListTeseh();
        }, 3000);
      });
  };

  public startConnectionShortListCapRaise = () => {
    this.hubConnectionShortListCapRaise
      .start()
      .then(() => {
        console.log("Connection to ShortListCapRaise Started ...");
        this.registerShortListCapRaiseSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListCapRaise connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListCapRaise();
        }, 3000);
      });
  };

  public startConnectionShortListHajm = () => {
    this.hubConnectionShortListHajm
      .start()
      .then(() => {
        console.log("Connection to ShortListHajm Started ...");
        this.registerShortListHajmSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListHajm connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListHajm();
        }, 3000);
      });
  };

  public startConnectionShortListIPO = () => {
    this.hubConnectionShortListIPO
      .start()
      .then(() => {
        console.log("Connection to ShortListIPO Started ...");
        this.registerShortListIPOSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListIPO connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListIPO();
        }, 3000);
      });
  };

  public startConnectionShortListPair = () => {
    this.hubConnectionShortListPair
      .start()
      .then(() => {
        console.log("Connection to ShortListPair Started ...");
        this.registerShortListPairSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListPair connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListPair();
        }, 3000);
      });
  };

  public startConnectionShortListPaye = () => {
    this.hubConnectionShortListPaye
      .start()
      .then(() => {
        console.log("Connection to ShortListPaye Started ...");
        this.registerShortListPayeSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListPaye connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListPaye();
        }, 3000);
      });
  };

  public startConnectionShortListSarma = () => {
    this.hubConnectionShortListSarma
      .start()
      .then(() => {
        console.log("Connection to ShortListSarma Started ...");
        this.registerShortListSarmaSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListSarma connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListSarma();
        }, 3000);
      });
  };

  
  public startConnectionShortListStoRight = () => {
    this.hubConnectionShortListStoRight
      .start()
      .then(() => {
        console.log("Connection to ShortListStoRight Started ...");
        this.registerShortListStoRightSignalEvents();
      })
      .catch((err) => {
        console.log("Error while starting ShortListStoRight connection:" + err);
        setTimeout(() => {
          this.startConnectionShortListStoRight();
        }, 3000);
      });
  };

  private registerAnotherSignalEvents() {
    this.hubConnection.on("newValue", (data: number) => {
      this.anotherSignalReceived.emit(data);
    });
  }

  private registerShortListSahamSignalEvents() {
    this.hubConnectionShortListSaham.on(
      "shortlist_sahamDto",
      (data: ShortList_SahamDto[]) => {
        this.shortListSahamSignalReceived.emit(data);
      }
    );
  }

  private registerShortListAkhzaSignalEvents() {
    this.hubConnectionShortListAkhza.on(
      "shortlist_AkhzaDto",
      (data: ShortList_AkhzaDto[]) => {
        this.shortListAkhzaSignalReceived.emit(data);
      }
    );
  }

  private registerShortListIndustrySignalEvents() {
    this.hubConnectionShortListIndustry.on(
      "shortlist_IndustryDto",
      (data: ShortList_IndustryDto[]) => {
        this.shortListIndustrySignalReceived.emit(data);
      }
    );
  }

  private registerShortListOptionSignalEvents() {
    this.hubConnectionShortListOption.on(
      "shortlist_OptionDto",
      (data: ShortList_OptionDto[]) => {
        this.shortListOptionSignalReceived.emit(data);
      }
    );
  }

  private registerShortListSandoghSignalEvents() {
    this.hubConnectionShortListSandogh.on(
      "shortlist_SandoghDto",
      (data: ShortList_SandoghDto[]) => {
        this.shortListSandoghSignalReceived.emit(data);
      }
    );
  }

  private registerShortListOraghSignalEvents() {
    this.hubConnectionShortListOragh.on(
      "shortlist_OraghDto",
      (data: ShortList_OraghDto[]) => {
        this.shortListOraghSignalReceived.emit(data);
      }
    );
  }

  private registerShortListSarkhatiSignalEvents() {
    this.hubConnectionShortListSarkhati.on(
      "shortlist_SarkhatiDto",
      (data: ShortList_SarkhatiDto[]) => {
        this.shortListSarkhatiSignalReceived.emit(data);
      }
    );
  }

  private registerShortListTesehSignalEvents() {
    this.hubConnectionShortListTeseh.on(
      "shortlist_TesehDto",
      (data: ShortList_TesehDto[]) => {
        this.shortListTesehSignalReceived.emit(data);
      }
    );
  }

  private registerShortListCapRaiseSignalEvents() {
    this.hubConnectionShortListCapRaise.on(
      "shortlist_CapRaiseDto",
      (data: ShortList_CapRaiseDto[]) => {
        this.shortListCapRaiseSignalReceived.emit(data);
      }
    );
  }

  private registerShortListHajmSignalEvents() {
    this.hubConnectionShortListHajm.on(
      "shortlist_HajmDto",
      (data: ShortList_HajmDto[]) => {
        this.shortListHajmSignalReceived.emit(data);
      }
    );
  }

  private registerShortListIPOSignalEvents() {
    this.hubConnectionShortListIPO.on(
      "shortlist_IPODto",
      (data: ShortList_IPODto[]) => {
        this.shortListIPOSignalReceived.emit(data);
      }
    );
  }

  private registerShortListPairSignalEvents() {
    this.hubConnectionShortListPair.on(
      "shortlist_PairDto",
      (data: ShortList_PairDto[]) => {
        this.shortListPairSignalReceived.emit(data);
      }
    );
  }

  private registerShortListPayeSignalEvents() {
    this.hubConnectionShortListPaye.on(
      "shortlist_PayeDto",
      (data: ShortList_PayeDto[]) => {
        this.shortListPayeSignalReceived.emit(data);
      }
    );
  }

  private registerShortListSarmaSignalEvents() {
    this.hubConnectionShortListSarma.on(
      "shortlist_SarmaDto",
      (data: ShortList_SarmaDto[]) => {
        this.shortListSarmaSignalReceived.emit(data);
      }
    );
  }

  private registerShortListStoRightSignalEvents() {
    this.hubConnectionShortListStoRight.on(
      "shortlist_StoRightDto",
      (data: ShortList_StoRightDto[]) => {
        this.shortListStoRightSignalReceived.emit(data);
      }
    );
  }

}
