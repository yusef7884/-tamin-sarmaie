import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class HttpRestService {

    headers = new HttpHeaders().set('Content-Type', 'application/json');
    baseUrl = '';
    httpUrl: string;
    httpConfigUrl: string;
    params = new HttpParams();

    constructor(private httpClient: HttpClient, private toastr: ToastrService) { }

    setBaseUrl(url: string) {
        this.baseUrl = url
    }
    addHeader(name: string, value: string) {
        this.headers = new HttpHeaders().append(name, value);
    }

    httpConfig(api: string, params: any, url: string) {

        url ? this.httpUrl = url : this.httpUrl = this.baseUrl;

        if (params == null || params == undefined) {
            this.httpConfigUrl = this.httpUrl + api;
        } else {
            if (Object.keys(params).length === 1) {
                let name = Object.keys(params)[0];
                this.params.set(name, params[name]);
                this.httpConfigUrl = this.httpUrl + api + "/" + params[0];
            } else {
                let nameParams = Object.keys(params);
                params.forEach((parameter: any, index: number) => {
                    let value = parameter[nameParams[index]];
                    this.params.append(nameParams[index], value)
                })
            }
        }
    }

    get(params: any, api: string, url = null): Observable<any> {
        let subject = new Subject<any>();
        this.httpConfig(api, params, url);
        this.httpClient.get(this.httpConfigUrl, {
            headers: this.headers,
            params: this.params,
            observe: 'response'
        }).subscribe((response) => {

            if (response.status == 200) {
                let res: any = response.body;

                if (!res.bRuleCode || res.bRuleCode === 1000) {
                    res.success = true;
                } else {
                    res.success = false;
                    this.toastr.error(res.message);
                }
                subject.next(response.body);
            } else {
                this.toastr.error('خطای برقراری با سرور');
            }
        });
        return subject.asObservable();
    }
    post(data: any, api: string, url = null): Observable<any> {
        let subject = new Subject<any>();

        this.httpConfig(api, null, url);
        this.httpClient.post(this.httpConfigUrl, data, {
            headers: this.headers,
            observe: 'response'
        }).subscribe((response) => {
            if (response.status == 200) {
                let res: any = response.body;
                if (!res.bRuleCode || res.bRuleCode === 1000) {
                    res.success = true;
                } else {
                    res.success = false;
                    this.toastr.error(res.message);
                }
                subject.next(response.body);
            } else {
                this.toastr.error('خطای برقراری با سرور');
            }

        })
        return subject.asObservable();
    }



}