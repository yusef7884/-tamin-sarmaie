export class RealLegalDto {
    hhp:string;
    data2:string;
    data3:string;
    constructor(hhp:string,data2:string,data3:string) {
        this.hhp = hhp;
        this.data2 = data2;
        this.data3=data3;
    }
}
