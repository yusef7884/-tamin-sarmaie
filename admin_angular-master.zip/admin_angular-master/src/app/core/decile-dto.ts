export class DecileDto {
    decile1:number;
    decile2:number;
    decile3:number;
    decile4:number;
    decile5:number;
    decile6:number;
    decile7:number;
    decile8:number;
    decile9:number;
    decile10:number;
}
