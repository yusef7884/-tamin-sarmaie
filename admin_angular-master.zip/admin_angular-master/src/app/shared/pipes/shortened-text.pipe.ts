import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shortenedText'
})
export class ShortenedTextPipe implements PipeTransform {

  transform(value: string, ...args: unknown[]): unknown {
    if (!value) return null;
    if (value.length <= 100) return value;
    return value.substr(0, 100) + '...';
  }

}