import { PipeTransform, Pipe } from '@angular/core';
import * as moment from 'moment-jalaali';

@Pipe({
    name: 'jMoment'
  })
  export class JalaliMomentPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        if (!value)
            return;
      return moment(value).format(args);
    }
  }
