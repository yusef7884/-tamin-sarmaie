
import { FormGroup } from '@angular/forms';


export function matchPassword(password: string, matchPassword: string) {
  return (formGroup: FormGroup) => {
    const newPassword = formGroup.controls[password];

    const confirmPassword = formGroup.controls[matchPassword];
    if (!newPassword || !confirmPassword) {
      return null;
    }
    if (confirmPassword.errors && !confirmPassword.errors.matchPassword) {
      return null;
    }
    if (newPassword.value !== confirmPassword.value) {
      confirmPassword.setErrors({ notMatchPassword: true });
    } else {
      confirmPassword.setErrors({ notMatchPassword: false });
    }
  }
}
