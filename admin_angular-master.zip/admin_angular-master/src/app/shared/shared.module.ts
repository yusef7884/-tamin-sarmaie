import { NgModule } from '@angular/core';
import { JalaliMomentPipe } from './pipes/jalali-moment.pipe';
import { ShortenedTextPipe } from './pipes/shortened-text.pipe';
import { PerfectScrollbarModule, PerfectScrollbarConfigInterface, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { MatFormFieldModule, MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GridModule } from '@progress/kendo-angular-grid';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { RTL } from '@progress/kendo-angular-l10n';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatRadioModule } from '@angular/material/radio';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatGridListModule } from '@angular/material/grid-list';
import { AgGridModule } from 'ag-grid-angular';
import { DailyInfoChartComponent } from './daily-info-chart/daily-info-chart.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { ChartModule } from 'angular-highcharts';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};

@NgModule({
    declarations: [
        JalaliMomentPipe,
        ShortenedTextPipe,
        DailyInfoChartComponent
    ],
    exports: [
        JalaliMomentPipe,
        ShortenedTextPipe,
        PerfectScrollbarModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatRadioModule,
        GridModule,
        DropDownsModule,
        NgbModule,
        MatSelectModule,
        MatTooltipModule,
        MatMenuModule,
        MatProgressBarModule,
        MatTabsModule,
        MatIconModule,
        MatExpansionModule,
        MatSidenavModule,
        MatGridListModule,
        DailyInfoChartComponent
        
    ],
    imports: [
        PerfectScrollbarModule,
        FormsModule,
        ReactiveFormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        MatRadioModule,
        GridModule,
        DropDownsModule,
        NgbModule,
        MatSelectModule,
        MatTooltipModule,
        MatMenuModule,
        MatProgressBarModule,
        MatTabsModule,
        MatIconModule,
        MatExpansionModule,
        MatSidenavModule,
        AgGridModule.withComponents(),
        HighchartsChartModule,
        ChartModule,
        MatAutocompleteModule,
        MatSlideToggleModule
    ],
    providers: [
        { provide: RTL, useValue: true },
        {
            provide: PERFECT_SCROLLBAR_CONFIG,
            useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
        },
        {
            provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
            useValue: { appearance: 'outline' },
        }
    ]
})
export class SharedModule { }
