import { Injectable } from "@angular/core";
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class GetDailyInfosService {
    constructor(private restService: HttpRestService) { }

    api = {
        GetDailyInfosApi: "MarketData/GetDailyInfos"
    }

    GetDailyInfos(IsInList: any) {
        return this.restService.post(IsInList, this.api.GetDailyInfosApi);
    }
}