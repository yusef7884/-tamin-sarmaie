import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DailyInfoChartComponent } from './daily-info-chart.component';

describe('DailyInfoChartComponent', () => {
  let component: DailyInfoChartComponent;
  let fixture: ComponentFixture<DailyInfoChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DailyInfoChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyInfoChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
