import { Component, OnInit, Input } from '@angular/core';
import { StockChart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import { GetDailyInfosService } from './GetdailyinfosService';

@Component({
  selector: 'app-daily-info-chart',
  templateUrl: './daily-info-chart.component.html',
  styleUrls: ['./daily-info-chart.component.scss'],
  providers: [GetDailyInfosService],
})

export class DailyInfoChartComponent implements OnInit {
  //@Input() IsInList:string[]
  _IsInList: string[];
  @Input() set IsInList(value: string[]) {
    this._IsInList = value;
    if (value) {
      this.LoadData();
    }
  }
  data: Array<any>;
  compareChart: StockChart;

  constructor(private service: GetDailyInfosService) {
  }

  ngOnInit(): void {
  }
  LoadData() {
    let param = {
      Entity: this._IsInList
    }
    this.service.GetDailyInfos(param).subscribe(response => {
      if (response.success) {
        this.data = response.result;
        this.chart();
      }
    });
  }
  chart() {
    
    let series = [];
    let counter = 0;
    this._IsInList.forEach(isin => {
      
      var isinData = this.data.filter(x => x.isin === isin);
      if (isinData.length > 0) {
        const trendValues: number[][] = [];

        isinData.map((item, i) => {
          let trendDate = item.dayDateText;
          trendValues[i] = [trendDate, item.closePrice];

        })
        series.push({
          yAxis: 0, 
          name: isinData[0].symbolFa,
          type: 'line',
          data: trendValues,
          color: Highcharts.getOptions().colors[counter],
        }
        );
        counter = counter + 1;
      }
    });

    let _compareChart = new StockChart({
      chart: {
        backgroundColor: 'transparent',
        zoomType: "x"
      },
      series: series,
      xAxis: [
        {
          tickColor: 'white',
          tickWidth: 1,
          labels: {
            align: 'right',
            x: -3,
            style: { color: 'white' },
            formatter: function () {
              return '' + this.value;
            }
          },
          offset: 0,
          lineWidth: 6
        }
      ],

      yAxis: [
        {
          gridLineColor: 'transparent',
          labels: {
            align: 'right',
            x: -3,
            style: { color: 'white' }
          },
          lineWidth: 6,
          opposite: false,
          resize: {
            enabled: true
          }
        }
      ],

      legend: {
        enabled: true,
        rtl:true,
        align: 'right',
        verticalAlign: 'top',
        layout: 'vertical',
        symbolWidth: 50,
        itemStyle: {
          color: 'white'
        }
      },

      tooltip: {
        useHTML:true,
        pointFormat: '{series.name} : <strong dir="ltr" >{point.y}</strong><br/>',
        split: true
      },
      rangeSelector: {
        enabled: false
      },
    });
    this.compareChart = _compareChart;

  }

}
