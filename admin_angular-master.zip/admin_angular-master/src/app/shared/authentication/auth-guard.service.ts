import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { RepositoryService } from '@app/services/repository.service';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private repositoryService : RepositoryService , private router : Router){}    

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
        Observable<boolean> | boolean{
            let allPages = this.repositoryService.pages.getAllpages();
            if(allPages.length === 0){
                let authenticated = this.repositoryService.pages.accessToPageByService(state.url);
                var subject = new Subject<any>();
                
                authenticated.subscribe(res => {
                    if(!res){
                        this.router.navigate(['errors/error-403']);
                    }
                    subject.next(res.value)
                });
                return subject.asObservable();
            }else{
                let isAuthenticated = this.repositoryService.pages.accessToPageWithoutService(state.url);
                if(!isAuthenticated){
                    this.router.navigate(['errors/error-403']);
                }
                return isAuthenticated;
            }
           
    }

}