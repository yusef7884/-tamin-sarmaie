import { Injectable } from '@angular/core';
import { HttpRestService } from '@app/core/httpRestService';

@Injectable()
export class AuthService {
    constructor(private restService: HttpRestService) { }

    api = {
        getAllPageAccessByUserNameApi: "resource/getallpageaccessbyusername"
    }
    getAllPageAccessByUserName() {
        return this.restService.post(null, this.api.getAllPageAccessByUserNameApi);
    }
}