import { Directive, OnInit } from '@angular/core';
import { MatInput } from '@angular/material/input';

@Directive({
  selector: '[matInputAutofocus]',
})
export class AutoFocusDirective implements OnInit {

  constructor(private matInput: MatInput) { }

  ngOnInit() {
    console.log(this.matInput);
    setTimeout(() => this.matInput.focus());
  }

}