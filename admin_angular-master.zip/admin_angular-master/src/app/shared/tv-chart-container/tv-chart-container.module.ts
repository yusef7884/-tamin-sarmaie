import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TvChartContainerComponent } from './tv-chart-container.component';

@NgModule({
    imports: [CommonModule],
    exports: [CommonModule, TvChartContainerComponent],
    declarations: [TvChartContainerComponent],
    providers: []
})
export class TvChartContainerModule {
}