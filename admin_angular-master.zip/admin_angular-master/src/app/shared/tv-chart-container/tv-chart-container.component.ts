import { Component, Input, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { widget, IChartingLibraryWidget, ChartingLibraryWidgetOptions, LanguageCode } from '../../../assets/tradingview/charting_library/charting_library.min';

@Component({
  selector: 'app-tv-chart-container',
  templateUrl: './tv-chart-container.component.html',
  styleUrls: ['./tv-chart-container.component.css']
})
export class TvChartContainerComponent implements OnInit, OnDestroy {
  private _symbol: ChartingLibraryWidgetOptions['symbol'] = 'NoSymbol';
  private _interval: ChartingLibraryWidgetOptions['interval'] = 'D';
  // BEWARE: no trailing slash is expected in feed URL
  // private _datafeedUrl = 'https://demo_feed.tradingview.com';
  private _datafeedUrl = 'https://rlcwebapi.tadbirrlc.com/ChartData';
  //private _datafeedUrl = 'http://localhost:5500';
  private _libraryPath: ChartingLibraryWidgetOptions['library_path'] = '/assets/tradingview/charting_library/';
  private _chartsStorageUrl: ChartingLibraryWidgetOptions['charts_storage_url'] = 'https://saveload.tradingview.com';
  private _chartsStorageApiVersion: ChartingLibraryWidgetOptions['charts_storage_api_version'] = '1.1';
  private _clientId: ChartingLibraryWidgetOptions['client_id'] = 'tradingview.com';
  private _userId: ChartingLibraryWidgetOptions['user_id'] = 'public_user_id';
  private _fullscreen: ChartingLibraryWidgetOptions['fullscreen'] = false;
  private _autosize: ChartingLibraryWidgetOptions['autosize'] = true;
  private _containerId: ChartingLibraryWidgetOptions['container_id'] = 'tv_chart_container';
  private _tvWidget: IChartingLibraryWidget | null = null;

  @Input()
  set symbol(symbol: ChartingLibraryWidgetOptions['symbol']) {
    console.log(symbol);
    this._symbol = symbol || this._symbol;
  }

  @Input()
  set interval(interval: ChartingLibraryWidgetOptions['interval']) {
    this._interval = interval || this._interval;
  }

  @Input()
  set datafeedUrl(datafeedUrl: string) {
    this._datafeedUrl = datafeedUrl || this._datafeedUrl;
  }

  @Input()
  set libraryPath(libraryPath: ChartingLibraryWidgetOptions['library_path']) {
    this._libraryPath = libraryPath || this._libraryPath;
  }

  @Input()
  set chartsStorageUrl(chartsStorageUrl: ChartingLibraryWidgetOptions['charts_storage_url']) {
    this._chartsStorageUrl = chartsStorageUrl || this._chartsStorageUrl;
  }

  @Input()
  set chartsStorageApiVersion(chartsStorageApiVersion: ChartingLibraryWidgetOptions['charts_storage_api_version']) {
    this._chartsStorageApiVersion = chartsStorageApiVersion || this._chartsStorageApiVersion;
  }

  @Input()
  set clientId(clientId: ChartingLibraryWidgetOptions['client_id']) {
    this._clientId = clientId || this._clientId;
  }

  @Input()
  set userId(userId: ChartingLibraryWidgetOptions['user_id']) {
    this._userId = userId || this._userId;
  }

  @Input()
  set fullscreen(fullscreen: ChartingLibraryWidgetOptions['fullscreen']) {
    this._fullscreen = fullscreen || this._fullscreen;
  }

  @Input()
  set autosize(autosize: ChartingLibraryWidgetOptions['autosize']) {
    this._autosize = autosize || this._autosize;
  }

  @Input()
  set containerId(containerId: ChartingLibraryWidgetOptions['container_id']) {
    this._containerId = containerId || this._containerId;
  }



  changeSymbol(symbol?: string) {
    if (symbol !== undefined && symbol !== null) {
      this._tvWidget.setSymbol(symbol, this._interval, () => { });
    }
  }


  ngOnInit() {
    function getLanguageFromURL(): LanguageCode | null {
      const regex = new RegExp('[\\?&]lang=([^&#]*)');
      const results = regex.exec(location.search);
      return results === null ? null : (decodeURIComponent(results[1].replace(/\+/g, ' ')) as LanguageCode);
    }

    const widgetOptions: ChartingLibraryWidgetOptions = {
      symbol: this._symbol,
      datafeed: new (window as any).Datafeeds.UDFCompatibleDatafeed(this._datafeedUrl, 100000),
      // datafeed: new DataFeed(),
      interval: '',
      container_id: this._containerId,
      library_path: this._libraryPath,
      // locale: getLanguageFromURL() || 'en',
      locale: getLanguageFromURL() || 'fa',
      disabled_features: ['use_localstorage_for_settings'],
      // enabled_features: ['study_templates'],
      charts_storage_url: this._chartsStorageUrl,
      charts_storage_api_version: this._chartsStorageApiVersion,
      client_id: this._clientId,
      user_id: this._userId,
      fullscreen: this._fullscreen,
      //   autosize: this._autosize,
      autosize: true,
      debug: false,
      // enabled_features:
      theme: 'Dark',
      timezone: 'Asia/Tehran',
      overrides: {
        'mainSeriesProperties.style': 1,
        'paneProperties.background': '#01102b',
        'paneProperties.vertGridProperties.color': '#363c4e',
        'paneProperties.horzGridProperties.color': '#363c4e',
        'symbolWatermarkProperties.transparency': 90,
        'scalesProperties.textColor': '#AAA',
        'mainSeriesProperties.candleStyle.wickUpColor': '#336854',
        'mainSeriesProperties.candleStyle.wickDownColor': '#7f323f'
      },
      customFormatters: {
        dateFormatter: {
          format(input) {
            // input.setDate(input.getDate() + 1);
            // console.log(input, 'MGD_EN');
            // console.log(input.toLocaleDateString('fa-IR'), 'MGD_FA');

            return input.toLocaleDateString('fa-IR');
          },
          formatLocal() {
            // console.log(' ---- formatting local date');
            return '3';
          }
        },
        timeFormatter: {
          format() {
            return '4';
          },
          formatLocal() {
            // console.log(' ---- formatting local time');
            return '5';
          }
        }
      }
    };

    let tvWidget = new widget(widgetOptions);
    this._tvWidget = tvWidget;

    // this.traderConfigService.getConfig().subscribe(config => {
    //   widgetOptions.overrides['paneProperties.background'] = config.colorTheme === 'theme-dark' ? '#1b1b1d' : '#f4f4f4';
    //   widgetOptions.theme = config.colorTheme === 'theme-dark' ? 'Dark' : 'Light';
    //   tvWidget = new widget(widgetOptions);
    //   // this._tvWidget.changeTheme(config.colorTheme === 'theme-dark' ? 'Dark' : 'Light');
    //   this._tvWidget = this._tvWidget;
    // });

    tvWidget.onChartReady(() => {
      const button = tvWidget.createButton()
        .attr('title', 'Click to show a notification popup')
        .addClass('apply-common-tooltip')
        .on('click', () =>
          tvWidget.showNoticeDialog({
            title: 'Notification',
            body: 'TradingView Charting Library API works correctly',
            callback: () => {
              // console.log('Noticed!');
            }
          })
        );

      button[0].innerHTML = 'Check API';
    });
  }

  ngOnDestroy() {
    if (this._tvWidget !== null) {
      // this._tvWidget.remove();
      this._tvWidget = null;
    }
  }
}
